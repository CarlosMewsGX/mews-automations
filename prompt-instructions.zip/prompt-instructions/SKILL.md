---
name: Prompt Instructions
description: Apply the instructions element when constructing a prompt: sub-tasks, obligation levels, conditional logic, phrasing techniques, and required content patterns.
---

# SKILL: Prompt Instructions

## Purpose
The Instructions section is the detailed roadmap for the model. It provides the specific execution steps needed to tackle the key task and achieve the goal established in context setting. Think of it as breaking down a complex objective into a sequence of clear, manageable actions.

---

## Sub-task Instructions

Sub-tasks break the main task into smaller, focused steps. Each step represents a specific action, constraint, or requirement that contributes to the overall objective.

**Types:**
- **Parallel** — individual instructions that can happen in any order (use bullet points)
- **Sequential** — instructions that must occur in a specific order (use numbered lists)

### Writing Effective Sub-tasks

- Each sub-task needs a single, well-defined objective — use clear verbs, avoid ambiguity
- Follow a logical sequence that makes sense for achieving the overall goal
- If a later step depends on an earlier one, explicitly reference it: `Using the summary you generated in step 1...`
- Use numbers rather than words like "first" or "next" to reduce ambiguity
- Limit each step to **one action** — never combine: `Analyse the case and extract the contact info` → split into two steps
- For complex prompts with multiple sub-task groups, label each section uniquely
- Use delimiters to separate different types of data or formats within instructions

### Guiding Questions

**Logical flow:**
- Do steps need to happen in a particular order?
- What happens first, second, and so on?

**Granularity:**
- What level of detail is needed for each step?
- What input and output is needed for each step?

**Conditional logic:**
- Does the process involve any if-then scenarios?
- What are the conditions and the corresponding actions?

**Mandatory content:**
- What specific data, facts, or arguments must be present?
- What are the required sections or structural features?
- Are there keywords or phrases to include or avoid?

**Data scope:**
- Do you need to filter or select specific records or data points?
- Are there specific time ranges or categories to focus on?

---

## Formulating Instructions

Instructions are typically a combination of rules and guardrails. They come in four forms:

| Type | Function | Examples |
|---|---|---|
| **Declarative** | Provide context or information the model needs | `The subject line should be concise and attention-grabbing.` |
| **Imperative** | Direct commands without an explicit subject | `Ignore null values.` / `Create a subject line less than 10 words.` |
| **Conditional** | Express conditions and their consequences | `If the input is invalid, then return an error message.` |
| **Deontic modality** | Express obligation, permission, or prohibition | `You must not generate toxic content.` |

---

## Multi-Step Instruction Patterns

### Numbered Steps (for ordered sequences)
```
Follow these steps precisely:
1. [instruction 1]
2. [instruction 2]
3. [instruction 3]
   a. [sub-instruction]
   b. [sub-instruction]
4. [instruction 4]
```

### Sequential Keywords (for lighter sequential framing)
```
First, [instruction 1]. Then, [instruction 2].
```

### Bullet Points (for parallel or unordered steps)
```
- [instruction]
- [instruction]
- [instruction]
```

---

## Degree of Obligation

The strength of language used to direct the model's actions. Use sparingly at the highest levels — overuse dilutes impact.

| Degree | Patterns | Notes |
|---|---|---|
| **Very High** | `must strictly + [verb]` / `must strictly not + [verb]` / `essential to + [verb]` / `crucial to + [verb]` / `vital to + [verb]` | Reserve for truly non-negotiable requirements. Use for guardrails and essential constraints. |
| **High** | `must + [verb]` / `must not + [verb]` / `required to + [verb]` / `ensure you + [verb]` / `strictly + [imperative]` | Firm requirement. The model is expected to follow this instruction. |
| **Medium-High** | `[imperative]` / `do not + [imperative]` / `need to + [verb]` / `important to + [verb]` | Direct command or strong necessity. Less formal than "must". |
| **Medium** | `should + [verb]` / `preferably + [imperative]` | Strong recommendation. Follow unless there's a good reason not to. |
| **Low** | `might + [verb]` / `could + [verb]` / `consider + [gerund]` | Suggestion. Encourages variability in output. |
| **Very Low** | `may + [verb]` / `may not + [verb]` | Permission or possibility. The model can choose to do it or not. |

**Best practices:**
- If you have several mandatory requirements, group them logically rather than starting each with `You must...`
- An overly prescriptive prompt stifles creativity and elegant solutions
- Reserve `must strictly` for critical, non-negotiable constraints only

---

## Character Limit Constraints

| Pattern | Examples |
|---|---|
| `...within [number] words` | `Generate an email within 100 words.` |
| `...under [number] characters` | `Keep responses brief (under 150 characters when answering questions)` |
| `...must not exceed [number] words` | `Your feedback must not exceed 300 words.` |

---

## Conditional Logic

### If-Then Evaluation

Checks a variable or phrase and tells the model what to do based on what it finds.

| Pattern | Examples |
|---|---|
| `If [variable] is [A], then output '[phrase A]'.` | `If a section is empty, then output "Not enough data for this section".` |
| `Check if [variable] is true, if true, [action A]. If false, [action B]` | `Check if "Application Form Input Error" is true, if true, return only the value of 'Error Message'...` |
| `If [condition], then [classification].` | `If symptoms match and contact confirmed, then classify as 'Probable'.` |

**Note:** In some cases, keeping if-then-else clauses within the same sentence produces better results. A full stop can cause the model to treat them as separate instructions. Experiment with this for your use case.

### Conditional Directives

For handling multiple variations of a scenario within a single prompt:

| Type | Pattern | Examples |
|---|---|---|
| **If-Then-Else** | `If [condition] is [value], then [A], otherwise [B].` | `If the tax calculation status is "CompletedWithTax", include both price before and after tax. Otherwise, only include total price.` |
| **Case-Switch** | `Based on [condition]: If it's [value 1], do [A]. If it's [value 2], do [B].` | Used for distinct scenarios with multiple possible values. |
| **Fallback Path** | `If none of the [X] criteria are met, classify as [Y].` / `If [condition] is empty or null, do [Y].` | Always provide explicit handling for missing or unmatched data. |

**Best practices:**
- Conditions must be based on specific data points the model has access to
- Always provide a fallback path — never leave the model without an explicit action for unmatched data
- Be specific rather than vague: `cases created in the last 30 days` not `recent cases`
- Place constraint instructions before the main task steps so the model knows its boundaries before it begins

---

## Phrasing Techniques

### Positive Phrasing

LLMs interpret `do not` as `do everything else`, leading to inconsistent output. Rephrase negatives as positive directives wherever possible.

| Negative Phrasing | Positive Phrasing |
|---|---|
| `Do not infer, assume, or generate additional content that is not part of the input.` | `Must strictly only use the data from the input to fill in each field.` |
| `Do not directly use the word "Seller", always refer to the seller using Seller Title.` | `Always refer to the seller by the Seller Title only.` |

### Verbatim Phrasing

When you need the model to output an exact phrase:

| Pattern | Examples |
|---|---|
| `...use the following, verbatim: [phrase]` | `Begin with the following sentence, verbatim: "Disclaimer: The current summary is based on the most recent data."` |
| `...with the following sentence verbatim: [phrase]` | `You must write the closing message with the following sentence verbatim: "Look forward to hearing from you!"` |
| `...you must strictly respond with [phrase]` | `If no information is available, you must strictly respond with "Unfortunately, I don't have enough information about this."` |

### Avoiding Echoed Instructions

Use adverbs to prevent the model from directly repeating your instruction language in its output:

| Pattern | Examples |
|---|---|
| `indirectly + [verb]` | `You want to indirectly express building a strong business relationship with [name].` |
| `subtly + [verb]` | `Subtly encourage the prospect to respond by showing willingness to answer questions.` |
| `convey that + [action]` | `You must convey that they can book a meeting at their convenience.` |

### Grounded-Only Constraints

Explicitly tell the model to stick to provided data without making anything up:

| Pattern | Examples |
|---|---|
| `Only use the data provided in [X]. Do not assume or fabricate information.` | `Use only the JSON provided. Do not make assumptions or add extra context.` |
| `The output must be generated exclusively from [X]. No assumptions, inferences, or fabricated information should be included.` | Used when input includes structured data like JSON or records. |
| `...strictly using the provided data.` | `You should summarise the case strictly using the provided input data.` |
| `You must not [X] anything that isn't provided.` | `Do not generate information that is not present in the provided data.` |

---

## Required Content Patterns

Use when the output must conform to a specific structure for consistency or downstream parsing.

| Type | Pattern | Examples |
|---|---|---|
| **List Items** | `Sections to include: [section 1], [section 2]...` | Define entities or fields to extract with brief descriptions. |
| **Statement** | `You must include [A], [B], and [C].` | `You must include the lead's first name and a motivating message to encourage the recipient to open the email.` |
| **Example Structure** | `Output Format: [content A] [content B]` | Provide a filled template directly in the prompt so the model mirrors the exact structure. Include heading labels and formatting conventions. |

---

## Instructions Checklist

Before moving to Data & Grounding, verify:

- [ ] Main task broken into clear, numbered or bulleted sub-steps
- [ ] Each step contains only one action
- [ ] Obligation level appropriate — `must strictly` reserved for truly critical requirements
- [ ] Conditional logic covers all cases including a fallback for missing/unmatched data
- [ ] Negative instructions rephrased as positive where possible
- [ ] Character or word limits specified if relevant
- [ ] Required output sections or fields listed
- [ ] Grounded-only constraints applied if the model should not infer beyond provided data
