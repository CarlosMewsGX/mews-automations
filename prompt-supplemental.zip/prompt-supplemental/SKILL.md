---
name: Prompt Supplemental Elements
description: Apply supplemental element guidance when constructing a prompt: task opening and closing directives, few-shot examples, section headers, delimiters, and pointer phrases.
---

# SKILL: Prompt Supplemental Elements

## Purpose
Supplemental elements aren't required in every prompt, but they are essential tools for complex prompts. They help structure the prompt for readability, enhance the model's understanding of its task, and improve consistency and accuracy of output. Use them when your prompt is multi-step, lengthy, or involves complex data structures.

**When to skip:** If your prompt is short, clear, and has a single obvious task, you don't need supplemental elements.

---

## 1. Task Opening and Closing

For complex prompts, a pair of task-framing directives tells the model to focus on a specific section and stay on track.

### Task Opening

Placed at the start of the prompt (or before the instructions section). Specifies where the model begins its work and signals it to follow the subsequent instructions precisely.

**Why use it:**
- Sets a clear expectation — the model understands the following instructions are paramount
- Reduces hallucinations — reduces the model's tendency to introduce its own interpretations or take creative liberties
- Improves predictability — produces more consistent outputs
- Supports complex workflows — helps the model understand it needs to follow the entire sequence of instructions

**Patterns:**

| Pattern | Examples |
|---|---|
| `When I ask you to [key task], you must strictly follow the [label] below.` | `When I ask you to generate a cold introduction email to your prospect, you must strictly follow my INSTRUCTIONS below.` |
| `For the following task, you must strictly adhere to the instructions provided.` | |
| `You are [role] and you are given a [input] that you need to [action] according to the [label] given below.` | `You are an expert copywriter and you are given a DRAFT EMAIL that you need to refine according to the REFINE INSTRUCTIONS given below.` |

**Best practices:**
- Concisely iterate the key task and reference the instructions section by name
- Use the exact same label you use for your instructions section

---

### Task Closing

Placed at the end of the prompt, after all instructions, data, and examples. Acts as a final trigger, signalling the model to now execute the main objective.

**Why use it:**
- Provides a clear execution signal — tells the model exactly when to initiate the core action
- Reduces ambiguity — in lengthy prompts, the model processes information sequentially; the closing clarifies the ultimate goal and prevents premature response generation
- Reinforces the main objective — brings the model's focus back to the primary goal

**Patterns:**

| Pattern | Examples |
|---|---|
| `Now [key task].` | `Now generate the introduction email.` |
| `Now [key task] from [data].` | `Now summarise the account from the DATA section below.` |
| `Now [key task] for [data].` | `Now draft the follow-up email for the prospect above.` |
| `Now [key task]. Ensure that [important rule].` | `Now generate the summary. Ensure that all monetary values use the correct currency symbol.` |
| `Now [key task]. You must [important constraint].` | `Now classify the sentiment. You must strictly only use the categories defined above.` |

**Best practices:**
- Wording should ideally mirror the task opening
- Consider placing grounding data immediately before or after the task closing when there is a single, focused data source — this helps the model apply the data directly to the task
- Use the task closing to re-emphasise the single most important rule

---

## 2. Input-Output Examples

Provide the model with clear demonstrations of the desired input-output format, content style, and structure. Showing is more effective than telling, especially for:

- **Complex formatting** — demonstrating intricate output structures (tables, nested lists, code) leaves less room for misinterpretation than describing them in words
- **Specific styles and tones** — examples convey subtle nuances in tone and voice that are hard to articulate through instructions alone
- **Clarifying ambiguity** — when instructions can be interpreted in multiple ways, examples provide concrete illustrations
- **Improving accuracy and relevance** — showing the desired relationship between input and output increases the likelihood of correct generation
- **Handling edge cases** — use examples to illustrate how to handle specific unusual scenarios

This technique is formally known as **Few-Shot Learning** when providing a small number of well-chosen examples within the prompt.

### Best Practices

- Clearly show both the expected input and the corresponding desired output
- Aim for concise examples that directly illustrate the point — avoid unnecessary complexity
- Choose examples that show the most important aspects: structure, style, how specific data types are handled
- Use realistic but anonymised data where possible
- For complex tasks, provide a few diverse examples covering different scenarios
- Verify examples are consistent with your written instructions for tone, style, and format
- Use clear delimiters to separate examples from instructions and from each other
- Add a brief explanation of what each example is intended to demonstrate
- Don't provide too many examples — a small number of well-chosen ones is more effective

### Pattern

```
## Example

### Input
"""
[example input — use realistic, anonymised data]
"""

### Output
"""
[desired output for the above input]
"""
```

### Positive and Negative Examples

For tone-critical tasks, provide both a good and bad example:

```
Good response (empathetic and helpful):
"Losing your customisations must be incredibly stressful. Let's see what we can do to recover them quickly."

Bad response (blunt and unhelpful):
"You should have saved your work. Try redoing it."
```

---

## 3. Structural Elements

Organise complex prompts into logical sections using clear headers, delimiters, and visual separators. This provides the model with explicit cues to understand the different parts of the prompt.

**Benefits:**
- Improved model comprehension — clear sections help the model identify the purpose of each part
- Enhanced accuracy — the model can correctly distinguish between instructions, context, and data
- Better human readability — well-structured prompts are easier to read, debug, and maintain
- Easier maintenance — a consistent structure makes it easier to identify and modify specific parts
- Better collaboration — a clear structure helps everyone understand how elements interact

### Section Headers

Group related commands and label them using descriptive noun phrases. Use Markdown-style headings for clear, hierarchical titles.

**Best practices:**
- Use meaningful headers that clearly indicate the purpose of the content
- Common sections: `## Context`, `## Instructions`, `## Output Format`, `## Data`, `## Examples`, `## Guardrails`
- Use descriptive headers — `## Customer Complaint Transcripts` not `## Data`
- Separate data in a dedicated section with clear delimiters to prevent the model from confusing data with instructions
- Assign labels to grounding data and refer to them consistently throughout the prompt

**Example structure:**
```
## Context
[context here]

## Key Task
[task here]

## Instructions
"""
[instructions here]
"""

## Data
"""
[grounding data here]
"""

## Example
[examples here]

## Guardrails
[guardrails here]
```

---

### Delimiters

Using delimiters helps the model accurately identify distinct sections of input, preventing misinterpretation.

| Type | Delimiter | Best Used For |
|---|---|---|
| Triple quotes | `"""` | Longer blocks of text or specific data |
| Triple backticks | ` ``` ` | Code blocks or clearly separating distinct blocks |
| Asterisks | `***` | Simple visual separators |
| Hyphens | `---` | Simple visual separators |
| XML tags | `<tag></tag>` | Semantic labelling of sections |
| Hash headers | `## Header ##` | Section titles with Markdown styling |
| Named labels | `###SECTION_NAME###` | Unique, referenceable section labels |

**Best practices:**
- Choose delimiters that make the prompt structure visually clear to human readers
- Use consistent delimiters throughout the prompt
- Avoid characters or sequences that appear naturally within your content
- Tell the model explicitly which delimiters you're using for complex structures: `I will use *** to separate distinct data.`
- For simple prompts (one or two parts), triple quotes or backticks usually suffice
- For highly structured prompts (multiple examples, multiple data sources), XML-like tags are most effective for semantic labelling
- When nesting information, use a different set of delimiters for the inner structure

**Examples:**
```
Instructions: """
[insert instructions here]
"""
```
```
<data>
[data here]
</data>
```
```
-----INSTRUCTIONS-----
[instructions here]
-----DATA-----
[data here]
```

---

### Pointer Phrases

Pointer phrases direct the model to specific sections of the prompt. They prevent confusion in long prompts with multiple labelled sections.

**Best practices:**
- Clearly delimit and name sections before using pointer phrases
- Use the exact same name or label that you used to define the section
- Be explicit — don't make the model guess which section you mean
- Place the pointer phrase within the instruction that needs to use the referenced section
- Enclose the referenced section name in quotes or use bold/italics for emphasis

**Examples:**
```
When I ask you to generate a cold introduction email to your prospect, you must strictly follow my INSTRUCTIONS below.
```
```
Now, looking at the 'User Goals' section defined earlier, suggest three features…
```
```
Extract the prospect's name, title, and company from the ###PROSPECT INFORMATION section below.
```

---

### Lists in Prompts

- Use **numbered lists** for step-by-step sequential instructions
- Use **bullet points** when order doesn't matter or you're providing a collection of related items
- Each list item should convey a single, distinct point or instruction
- Use concise and unambiguous language for each item
- Keep grammatical structure consistent across list items
- Use consistent bullet styles throughout the prompt
- For nested lists, use different markers and clear indentation — avoid more than 2-3 levels of nesting
- Providing instructions in list format strongly encourages the model to produce list-format output

---

### Visual Spacing

Add sufficient whitespace to improve readability for human prompt designers:

- Include blank lines between sections
- Break up large blocks of text into smaller paragraphs
- Use short sentences where possible
- Use tabs for indentation in nested structures

---

## Supplemental Elements Checklist

- [ ] Task opening included for complex, multi-step prompts
- [ ] Task opening concisely states the key task and references the instructions section by name
- [ ] Task closing mirrors the task opening wording
- [ ] Task closing placed after all instructions and data
- [ ] Most important rule re-emphasised in the task closing where relevant
- [ ] Examples provided for complex formatting, tone, or ambiguous instructions
- [ ] Examples use realistic, anonymised data
- [ ] Both good and bad examples provided for critical tone requirements
- [ ] Section headers are descriptive and consistent
- [ ] Delimiters used consistently throughout the prompt
- [ ] Nested structures use different delimiter sets
- [ ] Pointer phrases reference section labels exactly as defined
- [ ] Visual spacing and blank lines used to improve human readability
