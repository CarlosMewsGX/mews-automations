---
name: Prompt Tone and Style
description: Apply tone and style guidance when constructing a prompt: select and specify tone, style, linguistic features, and edge case handling for unfulfillable or inappropriate requests.
---

# SKILL: Prompt Tone and Style

## Purpose
The tone and style of model output significantly impacts how users perceive and interact with an AI experience. Getting it right improves comprehension, builds trust, reinforces brand voice, and makes output feel genuinely appropriate for its context. Tone and style are distinct but deeply intertwined:

- **Tone** — the emotional attitude or feeling the output evokes
- **Style** — how tone is expressed through specific linguistic choices: word choice, sentence structure, punctuation, jargon
- **Brand voice** — the distinct personality and set of values communicated consistently across all channels

---

## Key Considerations Before Choosing Tone

Before selecting a tone, consider:

| Factor | Questions to ask |
|---|---|
| **User goal and context** | What is the user trying to achieve? What is their likely emotional state? What has led them to this task? |
| **Audience** | Experts or novices? Internal teams or customers? What are their expectations? |
| **Task and objective** | Is the model providing information, generating creative content, guiding a process, or summarising data? |
| **Channel or setting** | Chatbot, email, in-app notification, detailed report? Brief SMS vs. formal document? |
| **Potential for misinterpretation** | How might the chosen tone be perceived differently by different users? |
| **Formality required** | Formal or informal? Consider audience, purpose, and cultural context. |

> **Note:** Tone is profoundly relative. "Kind" or "friendly" in one cultural context can read very differently in another. When prompting for global audiences, avoid tone descriptions that assume a single cultural norm.

---

## How to Specify Tone

### Step 1: Start Simple

Begin with a clear tone label. Most models understand widely recognised tone concepts from training data.

```
Adopt a professional and courteous tone.
The tone should be friendly and conversational, using everyday language and contractions.
Use an empathetic tone.
```

Evaluate the output. If it meets your needs consistently, you're done. If not, proceed to Step 2.

### Step 2: Contextualise and Specify

Add detail about the specific shade of the tone you want. "Professional" means different things for a lawyer vs. a customer service agent vs. a developer communicating an outage.

Ask:
- Is it about using formal language? Avoiding contractions? Maintaining objectivity? Being data-driven?
- Is "empathetic" about validating feelings, offering practical support, or expressing understanding of impact?
- Is "kind" actually about persuasion, closeness, or deference?

More precise alternatives:
- Instead of `kind` → try `deferential`, `warm`, `encouraging`
- Instead of `professional` → try `professional but warm`, `highly authoritative`, `consultative`
- Instead of `empathetic` → try `validating and solution-focused`

### Step 3: Provide Examples

Show the model what you want — don't just tell it. Provide positive and negative examples that illustrate the desired tone:

```
Examples of empathetic tone:

User: "I've lost all my recent report customisations and I'm panicking!"

Good response: "Losing your customisations must be incredibly stressful. Let's see what we can do to recover them or rebuild them quickly."

Bad response: "You should have saved your work. Try redoing it."
```

### Step 4: Reinforce Through Other Prompt Elements

Weave tone into other elements of the prompt:

- **Role definition**: `You are a considerate advisor who...`
- **Audience definition**: `...explain this to a non-technical user.`
- **Channel/setting**: `Craft a brief Slack message...`
- **Instructions**: `Remember, you are a friendly and helpful support assistant. Formulate your response to be encouraging and empathetic.`

---

## Common Tones

### Professional
Standard for most business communications. Conveys respect, competence, and formality without being overly stiff.

**Context variations:**
- **Sales context**: professional can mean confident, benefit-oriented, and slightly persuasive while maintaining respect
- **Service context**: professional can mean more formal, solution-focused, and patient, especially with complex issues

**Features:** Formal vocabulary, complete sentences and proper grammar, no slang or colloquialisms, objective language focused on facts and solutions, third-person perspective, non-discriminatory language

**Example instructions:**
- `You are a professional support agent who responds to customer enquiries with a formal and respectful tone.`
- `The tone should be professional, welcoming, and clearly outline the next steps. Avoid overly casual language.`

---

### Friendly
Aims to create a warm, positive, and welcoming interaction. Can be used in less formal contexts, for proactive outreach, or when building rapport.

**Context variations:**
- **With existing customers**: friendliness can be more familiar
- **With new leads**: friendliness should be balanced with professionalism

**Features:** Everyday, conversational language; slang used with caution; use of contractions; positive adjectives; first- and second-person pronouns; shorter sentences

**Example instructions:**
- `The tone should be friendly and conversational, using everyday language and contractions.`
- `Be friendly and approachable, but make sure the core message remains clear and professional.`

---

### Formal
Similar to Professional but with more emphasis on titles and honorifics, and avoiding contractions.

**Features:** Complex sentence structures, no colloquialisms, more detached perspective

**Example instruction:**
- `The tone should be formal and respectful, employing complex sentence structures and avoiding colloquialisms.`

---

### Helpful and Empathetic
Aims to understand and share the feelings of the reader. Acknowledges the user's emotional state and responds with care.

**Context variations:**
- **For complaints**: empathy means validating strong negative emotions and taking ownership
- **For feature requests or confusion**: empathy means patience and understanding of their perspective

**Features:** Expressions of understanding and shared feelings; focus on user needs and concerns; reflective listening cues; reassuring language; patient and understanding word choices; no blame or overly technical jargon; focus on positive actions and solutions

**Example instructions:**
- `Use an empathetic tone. Acknowledge the user's stated emotion directly. Validate their feelings by saying 'It's understandable that you feel X.' Avoid platitudes like 'I'm sorry for the inconvenience' unless truly applicable. Focus on offering concrete next steps.`

---

### Neutral and Objective
Presents information factually without expressing personal opinions, feelings, or biases. Suitable for reporting, data summaries, or when impartiality is key.

**Features:** No emotive words or subjective adjectives; focus on data, facts, and observable events; third-person perspective; formal vocabulary and precise language; attribution of sources where necessary

**Example instructions:**
- `Adopt a neutral and factual tone.`
- `The tone must be strictly objective, presenting the data clearly without any positive or negative spin.`

---

### Persuasive
Aims to convince the audience to take a specific action or adopt a particular viewpoint. Common in sales and marketing communications.

**Context variations:**
- **Soft persuasion**: gentle encouragement and highlighting benefits without being pushy
- **Strong persuasion**: more assertive and direct call to action

**Features:** Language designed to convince or influence; focus on benefits and value propositions; strong action verbs and calls to action; rhetorical questions; positive framing; addresses potential objections proactively; emotional appeals when appropriate; logical arguments

**Example instructions:**
- `The tone should be persuasive, highlighting the benefits and encouraging a response.`
- `Gently persuade the user to complete their profile by highlighting the benefits of a complete profile.`

---

### Concise and Direct
Gets straight to the point without unnecessary content. Values clarity, brevity, and efficiency.

**Context variations:**
- **For technical instructions**: direct means unambiguous and step-oriented
- **For busy executives**: direct means bottom-line upfront

**Features:** Short, direct sentences and paragraphs; no unnecessary words or phrases; focus on key information; active voice; clear and unambiguous language; avoidance of jargon unless audience is technical; bullet points or numbered lists for key takeaways

**Example instructions:**
- `The tone should be concise and to the point, avoiding unnecessary details.`
- `Adopt a direct and to-the-point tone. Clearly state the expected impact.`

---

### Confident
Conveys assurance, expertise, and belief in the information or solution being presented. Important for building trust, especially when providing expert advice.

**Features:** Declarative statements; avoidance of hesitant language; strong, positive assertions; clear and direct phrasing. Can be combined with Professional or Persuasive tones.

**Important:** Balance confidence with respect and humility.

**Example instructions:**
- `You are a confident solutions expert.`
- `The tone should be confident and engaging, clearly stating the value proposition.`

---

## Common Styles

### Clear and Simple
Precise language, unambiguous words, common vocabulary. Conveys information using the fewest words possible without sacrificing clarity.

**Features:** Simple, short sentences; logical flow; active voice; no redundant words or phrases; strong verbs; focus on essential information; bullet points or numbered lists

**Example instructions:**
- `Use clear and concise language.`
- `Write for an 8th grade reading level, using common vocabulary.`

---

### Conversational
Mimics natural human conversation. Less formal and aims to be engaging and relatable.

**Features:** Contractions and appropriate colloquialisms; questions directed at the reader; first and second person pronouns; shorter sentences; more relaxed flow; occasional interjections

**Example instructions:**
- `Adopt a conversational style.`
- `Rewrite the document into a more conversational style suitable for a blog post aimed at marketing beginners.`

---

### Action-Oriented
Prompts immediate activity, decision-making, or next steps. Language geared towards motivating the reader to *do* something.

**Features:** Strong verbs; heavy use of imperative verbs; clear calls to action; direct and unambiguous instructions; numbered or bulleted lists; references to deadlines or time-sensitive language; concise sentences; no passive constructions for action items

**Example instructions:**
- `Craft a short, action-oriented reminder that clearly states what needs to be done and the deadline.`

---

### Data-Driven
Presents information, makes arguments, or supports conclusions primarily through concrete data, statistics, metrics, and factual evidence. Often paired with Neutral, Confident, or Professional tone.

**Features:** Claims supported by data; specific numbers, percentages, metrics, and quantifiable results; charts, graphs, or tables; emphasis on facts and evidence over opinions

**Example instructions:**
- `Adopt a data-driven style.`
- `Justify the need for additional training on the feature using a data-driven style.`

---

### Benefit-Oriented
Frames information around advantages, value, positive outcomes, or solutions. Answers the "What's in it for me?" question. Often used with a Persuasive tone.

**Features:** Focus on how the product or service addresses pain points; emphasis on positive outcomes and advantages; second-person pronouns to directly address the audience; translation of features into tangible benefits; positive and aspirational language

**Example instructions:**
- `Use a benefit-oriented style, highlighting the added value and peace of mind.`

---

### Technical
Presents complex, specialised information clearly and accurately to a specific audience that understands the subject matter. Precision is paramount.

**Features:** Industry-specific jargon; precise terminology; focus on factual information; passive voice where the action is more important than the actor; diagrams, code snippets, or structured data

**Example instructions:**
- `The writing style should be technical, using precise industry jargon when appropriate.`
- `Use a precise and technical style.`

---

### Creative and Descriptive
Paints a picture with words, appealing to the senses. About showing rather than just telling. Consider for product descriptions, explaining complex concepts with analogies, creating engaging narratives from data, or scene-setting.

**Features:** Figurative language; rich in adjectives and adverbs; sensory language; imaginative expressions; unique phrasing used cautiously

**Example instructions:**
- `The style can be creative and engaging, using figurative language where appropriate.`
- `Use a descriptive style that highlights the innovative features and paints a picture.`

---

## Handling Edge Cases

Adapt tone for challenging utterances:

### Unfulfillable Requests
The task is relevant but the model is unable to complete it (missing data, impossible request, error).

**Tone:** Courteous, acknowledging, clear, helpful, offering alternatives
**Example instruction:** `If the user asks for something you cannot do, politely explain the limitation and suggest an alternative action or resource.`

### Non-Serious Requests
The request appears relevant but contains nonsensical or frivolous details — the user is testing the system.

**Tone:** Neutral, calm, possibly slightly firm but not confrontational. Gently redirect.
**Example instruction:** `If the user input is nonsensical but related to the task, do not generate a creative story — state that you can only assist with supported features and redirect them back to a standard request.`

### Inappropriate Requests
Harmful, invasive, or off-topic prompts that aren't related to the task.

**Tone:** Firm, clear, non-engageable, aligned with safety guardrails. Not preachy or judgmental, but unambiguous.
**Example instruction:** `If the query is asking for private information, directly respond verbatim with: "I can't assist with that request." Do not provide further explanation or engage with the problematic request.`

---

## Mirroring User Tone

Consider instructing the model to subtly align with the user's communication style for standard interactions. This is rooted in the similarity-attraction effect — people respond more positively to communication styles that mirror their own.

**Rules:**
- Define the specific dimensions to mirror: formality, pace, level of detail, vocabulary, structure
- Set firm guardrails to stay within the defined brand voice and role
- Never mirror negative emotions like anger or use inappropriate language
- `If the user's query is brief and direct, provide a concise answer. If the user's query is longer and more descriptive, adopt a slightly more elaborative tone in your response, while remaining helpful and on-brand.`

---

## Tone and Style Checklist

- [ ] Tone selected based on audience, task, and channel — not just instinct
- [ ] Simple tone label tested first before adding detail
- [ ] Vague tone labels (e.g. "professional", "empathetic") contextualised with specific linguistic features
- [ ] Positive and negative examples provided for critical tone requirements
- [ ] Tone reinforced through role definition, audience description, and channel specification
- [ ] Edge case tones defined for unfulfillable, non-serious, and inappropriate requests
- [ ] Cultural context considered for global audiences
