# Jobs To Be Done (JTBD)

> Format: one JTBD per section. Keep them specific and testable.

## JTBD-001: <Job title>
- Type: (Core / Supporting / Emotional)
- When: <situation / trigger>
- I want to: <user motivation / action>
- So I can: <desired outcome>
- Success metric: <how they judge success>
- Frequency: (Low / Med / High) + rationale
- Severity: (Low / Med / High) + rationale
- Who: <persona / department>
- Where this happens today: <report/tool/workflow>
- Evidence:
  - Timestamp:
  - Quote:
- Notes / variants / edge cases:

---

## JTBD-002: <Job title>
- Type:
- When:
- I want to:
- So I can:
- Success metric:
- Frequency:
- Severity:
- Who:
- Where this happens today:
- Evidence:
  - Timestamp:
  - Quote:
- Notes / variants / edge cases:
