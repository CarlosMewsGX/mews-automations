# AI Summary

## Context
- What is the customer trying to achieve?
- What environment are they operating in (portfolio size, teams, tooling, constraints)?

## Key Problems
- Problem 1:
- Problem 2:
- Problem 3:

## Workflows & Behaviours
- Current workflow steps (as described):
  1.
  2.
  3.
- Workarounds / manual processes:
- What “good” looks like for them:

## Metrics & Definitions Mentioned
- Metric / definition:
- Report / screen they referenced:
- Any parity expectations vs PMS / legacy reports:

## Constraints & Trade-offs
- Constraints (technical, operational, data, process):
- Trade-offs they are making today:

## Desired Outcomes
- Outcome 1:
- Outcome 2:
- Outcome 3:

## Risks / Red Flags
- Where misunderstandings or ambiguity exist:
- Anything that could invalidate the insight:

## Recommended Follow-ups
- Questions to ask next time:
- Data / artifacts to request:
