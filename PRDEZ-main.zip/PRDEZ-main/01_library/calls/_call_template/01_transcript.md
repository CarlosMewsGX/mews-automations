# Transcript (Raw)

> Do not edit the transcript content (keep as source of truth).
> If you need to annotate, use `05_evidence_clips.md` or `06_followups.md`.

---

[PASTE TRANSCRIPT HERE]
