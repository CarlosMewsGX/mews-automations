# Call Metadata

## Identifiers
- Call ID:
- Source: (Gong / Zoom / Meet / Other)
- Recording link:
- Transcript source file:

## Date & Timing
- Date (YYYY-MM-DD):
- Timezone:
- Duration:

## Customer
- Customer name:
- Customer slug:
- Segment/cohort:
- Region:

## Participants
- Customer attendees:
- Mews attendees:
- Primary persona(s):

## Purpose
- Call type: (Discovery / Feedback / Support / Pilot / Beta / Other)
- Topic / focus area:
- Product area(s):

## Context Snapshot
- Current workflow/tools:
- Current pain level: (Low / Med / High)
- What triggered this conversation:

## Notes
- Anything sensitive / context to handle carefully:
- Follow-up owner (if any):
