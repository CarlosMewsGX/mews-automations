# Insights

> Insight = something true about behaviour/need that changes product thinking.
> Each insight must include evidence.

## INS-001: <Insight statement>
- Theme:
- Applies to: (segment / persona / customer type)
- Confidence: 0.0–1.0
- Evidence:
  - Timestamp:
  - Quote:
- What this implies for product:
- Hypotheses to validate:
  - H1:
  - H2:
- Notes / caveats:

---

## INS-002: <Insight statement>
- Theme:
- Applies to:
- Confidence:
- Evidence:
  - Timestamp:
  - Quote:
- What this implies for product:
- Hypotheses to validate:
- Notes / caveats:
