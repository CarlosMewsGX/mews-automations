# Follow-ups

## Open Questions
- Q1:
- Q2:
- Q3:

## Hypotheses (Low confidence)
- H1:
- H2:

## Requests to Customer
- Artifact request:
- Data sample request:
- Screenshot/report request:

## Actions
- [ ] Action 1 — Owner — Due date
- [ ] Action 2 — Owner — Due date

## Notes
- Anything to carry into the next call:
