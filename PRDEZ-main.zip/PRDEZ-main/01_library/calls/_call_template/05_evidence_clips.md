# Evidence Clips (Best Quotes)

> Keep clips short. Prefer high-signal quotes that would convince a skeptic.

## Clip 1 — <Title / why it matters>
- Timestamp:
- Speaker:
- Quote:
- Why it matters:
- Tags:

## Clip 2 — <Title / why it matters>
- Timestamp:
- Speaker:
- Quote:
- Why it matters:
- Tags:
