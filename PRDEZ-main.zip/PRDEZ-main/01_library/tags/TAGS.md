# Tags

## Product Areas
- revenue-management
- finance
- occupancy-availability
- pickup-pace
- distribution
- forecasting-budgeting
- multi-property
- permissions-governance
- exports-integrations
- trust-reconciliation

## Personas
- gm
- revenue-manager
- finance-manager
- ops-manager
- data-analyst
- owner-operator
- corporate-leadership

## Theme Tags
- metric-parity
- workflow-friction
- manual-work
- adoption-barrier
- data-quality
- explainability
