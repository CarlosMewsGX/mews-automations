#!/usr/bin/env python3
from __future__ import annotations

import inspect
import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Tuple
from urllib.parse import parse_qs, urlparse

from openai import AzureOpenAI


# ============================
# CONFIG MODEL
# ============================

@dataclass
class AzureOpenAIConfig:
    endpoint: str
    api_key: str
    api_version: str
    deployment: str


# ============================
# ENV LOADING
# ============================

def load_env_file(root: Path) -> None:
    env_path = root / ".env"
    if not env_path.exists():
        return

    for line in env_path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        os.environ.setdefault(key, value)


def parse_responses_url(responses_url: str) -> Tuple[str, Optional[str]]:
    parsed = urlparse(responses_url)
    endpoint = f"{parsed.scheme}://{parsed.netloc}".rstrip("/") + "/"
    api_version = None
    if parsed.query:
        api_version = parse_qs(parsed.query).get("api-version", [None])[0]
    return endpoint, api_version


def load_azure_openai_config(root: Path) -> AzureOpenAIConfig:
    load_env_file(root)

    responses_url = os.getenv("AZURE_OPENAI_RESPONSES_URL", "").strip()
    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT", "").strip()
    api_version = os.getenv("AZURE_OPENAI_API_VERSION", "").strip()

    if responses_url and (not endpoint or not api_version):
        parsed_endpoint, parsed_version = parse_responses_url(responses_url)
        if not endpoint:
            endpoint = parsed_endpoint
        if not api_version and parsed_version:
            api_version = parsed_version

    api_key = os.getenv("AZURE_OPENAI_API_KEY", "").strip()
    deployment = os.getenv("AZURE_OPENAI_DEPLOYMENT", "").strip()

    missing = [
        name
        for name, value in {
            "AZURE_OPENAI_ENDPOINT": endpoint,
            "AZURE_OPENAI_API_KEY": api_key,
            "AZURE_OPENAI_API_VERSION": api_version,
            "AZURE_OPENAI_DEPLOYMENT": deployment,
        }.items()
        if not value
    ]
    if missing:
        raise SystemExit(
            f"Missing required Azure OpenAI environment values: {', '.join(missing)}"
        )

    return AzureOpenAIConfig(
        endpoint=endpoint,
        api_key=api_key,
        api_version=api_version,
        deployment=deployment,
    )


# ============================
# CLIENT
# ============================

class AzureOpenAIClient:
    def __init__(self, config: AzureOpenAIConfig):
        self.config = config
        self.client = AzureOpenAI(
            api_version=config.api_version,
            azure_endpoint=config.endpoint,
            api_key=config.api_key,
        )

    def generate(
        self,
        prompt: str,
        temperature: float,
        max_output_tokens: int = 8192,
        response_format: Optional[dict] = None,
    ) -> str:
        """
        Compatible with openai==2.15.0 and newer.

        - Uses responses.create()
        - Only passes response_format if the SDK supports it
        """
        for attempt in range(1, 6):
            try:
                kwargs = dict(
                    model=self.config.deployment,
                    input=[{"role": "user", "content": prompt}],
                    temperature=temperature,
                    max_output_tokens=max_output_tokens,
                )

                # Conditionally include response_format (not supported in 2.15.0)
                sig = inspect.signature(self.client.responses.create)
                if response_format is not None and "response_format" in sig.parameters:
                    kwargs["response_format"] = response_format

                response = self.client.responses.create(**kwargs)

                text = self._extract_text(response)
                if text:
                    return text

                raise RuntimeError("Azure OpenAI response missing output text")

            except Exception as exc:
                status = getattr(exc, "status_code", None)
                if status in (429, 500, 502, 503, 504):
                    time.sleep(min(2 ** attempt, 20))
                    continue
                raise RuntimeError(f"Azure OpenAI API error: {exc}") from exc

        raise RuntimeError("Azure OpenAI API failed after retries")

    @staticmethod
    def _extract_text(response) -> str:
        """
        Works across SDK variants:
        - response.output_text (newer)
        - response.output[].content[].text (older)
        """
        output_text = getattr(response, "output_text", None)
        if output_text:
            return output_text

        texts = []
        for item in getattr(response, "output", []) or []:
            for content in getattr(item, "content", []) or []:
                if getattr(content, "type", None) == "output_text":
                    texts.append(getattr(content, "text", ""))
        return "".join(texts)
