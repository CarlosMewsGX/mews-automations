#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple


CHECK_EMOJI = " ✅"


# ----------------------------
# Paths
# ----------------------------

def repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def calls_processed_dir(root: Path) -> Path:
    return root / "01_library" / "calls" / "processed"


def customers_dir(root: Path) -> Path:
    return root / "01_library" / "customers"


def registry_dir(root: Path) -> Path:
    return customers_dir(root) / "_registry"


# ----------------------------
# Utilities
# ----------------------------

def read_text(p: Path) -> str:
    return p.read_text(encoding="utf-8", errors="replace")


def write_text(p: Path, text: str) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text.rstrip() + "\n", encoding="utf-8")


def safe_slug(s: str) -> str:
    s = s.strip().lower()
    s = s.replace("&", " and ")
    s = re.sub(r"[^a-z0-9]+", "-", s)
    s = re.sub(r"-{2,}", "-", s).strip("-")
    return s or "unknown"


def normalize_key(s: str) -> str:
    s = s.strip().lower()
    s = re.sub(r"\s+", " ", s)
    s = re.sub(r"[^\w\s-]", "", s)
    return s


def is_iso_date(d: str) -> bool:
    try:
        datetime.strptime(d, "%Y-%m-%d")
        return True
    except Exception:
        return False


def relpath_md(from_dir: Path, to_path: Path) -> str:
    return os.path.relpath(to_path, start=from_dir).replace("\\", "/")


# ----------------------------
# Call folder name parsing (fallback only)
# ----------------------------

def parse_call_folder_name(folder_name: str) -> Tuple[str, str, str]:
    name = folder_name[:-len(CHECK_EMOJI)] if folder_name.endswith(CHECK_EMOJI) else folder_name
    parts = name.split("__")
    if len(parts) >= 3:
        return parts[0], parts[1], "__".join(parts[2:])
    if len(parts) == 2:
        return parts[0], parts[1], "unknown-topic"
    return "unknown-date", "unknown-customer", "unknown-topic"


# ----------------------------
# Metadata parsing (SOURCE OF TRUTH)
# ----------------------------

META_CUSTOMER_ID_RE = re.compile(r"^\s*-\s*Customer ID:\s*(.+?)\s*$", re.MULTILINE | re.IGNORECASE)
META_CUSTOMER_RE = re.compile(r"^\s*-\s*Customer:\s*(.+?)\s*$", re.MULTILINE | re.IGNORECASE)
META_CALLTYPE_RE = re.compile(r"^\s*-\s*Call type:\s*(.+?)\s*$", re.MULTILINE | re.IGNORECASE)


@dataclass
class CallIdentity:
    customer_id: str
    customer_name: str
    call_type: str
    is_missing: bool


def resolve_identity_from_metadata(call_folder: Path) -> CallIdentity:
    meta_path = call_folder / "00_metadata.md"
    customer_id = "unknown"
    customer_name = "UNKNOWN"
    call_type = "UNKNOWN"
    missing = True

    if meta_path.exists():
        md = read_text(meta_path)

        ct = META_CALLTYPE_RE.search(md)
        if ct:
            call_type = ct.group(1).strip()

        cid = META_CUSTOMER_ID_RE.search(md)
        if cid:
            raw = cid.group(1).strip()
            if raw and raw.lower() not in ("unknown", "n/a", "na", "tbd"):
                customer_id = safe_slug(raw)
                missing = False

        cname = META_CUSTOMER_RE.search(md)
        if cname:
            raw = cname.group(1).strip()
            customer_name = raw if raw else customer_name
            if missing and raw and raw.lower() not in ("unknown", "n/a", "na", "tbd"):
                customer_id = safe_slug(raw)
                missing = False

    if customer_id == "unknown":
        _date, candidate, _topic = parse_call_folder_name(call_folder.name)
        candidate = safe_slug(candidate)
        if candidate and candidate not in ("unknown", "unknown-customer"):
            customer_id = candidate
            customer_name = candidate
            missing = True

    if call_type.strip().lower().startswith("internal"):
        customer_id = "internal"
        customer_name = "Internal / Mews"
        missing = False

    return CallIdentity(customer_id, customer_name, call_type, missing)


# ----------------------------
# Extract from call-level JTBD/Insights markdown
# Supports BOTH:
#   A) Structured headers (preferred)
#   B) Legacy bullet-only lists (fallback)
# ----------------------------

JTBD_HEADER_RE = re.compile(
    r"^#{2,3}\s*(JTBD[-\s]?\d+)\s*[:\-]\s*(.+?)\s*$",
    re.MULTILINE | re.IGNORECASE
)
INS_HEADER_RE = re.compile(
    r"^#{2,3}\s*((?:INS|INSIGHT)[-\s]?\d+)\s*[:\-]\s*(.+?)\s*$",
    re.MULTILINE | re.IGNORECASE
)

EVIDENCE_TS_RE = re.compile(r"^\s*-\s*Timestamp:\s*(.*)\s*$", re.MULTILINE)
EVIDENCE_QUOTE_RE = re.compile(r"^\s*-\s*Quote:\s*(.*)\s*$", re.MULTILINE)
CONF_RE = re.compile(r"^\s*-\s*Confidence:\s*([0-9.]+)\s*$", re.MULTILINE)
THEME_RE = re.compile(r"^\s*-\s*Theme:\s*(.*)\s*$", re.MULTILINE)
APPLIES_RE = re.compile(r"^\s*-\s*Applies to:\s*(.*)\s*$", re.MULTILINE)

# Fallback bullet-only:
BULLET_LINE_RE = re.compile(r"^\s*-\s+(.*\S)\s*$", re.MULTILINE)


@dataclass
class ExtractedItem:
    id: str
    title: str
    key: str
    body: str
    timestamp: str
    quote: str
    confidence: Optional[float] = None
    theme: Optional[str] = None
    applies_to: Optional[str] = None


def split_sections(md: str, header_re: re.Pattern) -> List[Tuple[str, str, str]]:
    matches = list(header_re.finditer(md))
    sections: List[Tuple[str, str, str]] = []
    for i, m in enumerate(matches):
        start = m.start()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(md)
        raw_id = m.group(1).strip()
        title = m.group(2).strip()
        section_text = md[start:end].strip()
        sections.append((raw_id, title, section_text))
    return sections


def _normalize_numeric_id(prefix: str, raw_id: str, idx_fallback: int) -> str:
    m = re.search(r"(\d+)", raw_id)
    if m:
        n = int(m.group(1))
        return f"{prefix}-{n:03d}"
    return f"{prefix}-{idx_fallback:03d}"


def extract_best_evidence(section_text: str) -> Tuple[str, str]:
    ts = ""
    q = ""
    ts_m = EVIDENCE_TS_RE.search(section_text)
    if ts_m:
        ts = ts_m.group(1).strip()
    q_m = EVIDENCE_QUOTE_RE.search(section_text)
    if q_m:
        q = q_m.group(1).strip()
    return ts, q


def extract_optional_fields(section_text: str) -> Tuple[Optional[float], Optional[str], Optional[str]]:
    conf = None
    theme = None
    applies = None

    cm = CONF_RE.search(section_text)
    if cm:
        try:
            conf = float(cm.group(1))
        except Exception:
            conf = None

    tm = THEME_RE.search(section_text)
    if tm:
        theme = tm.group(1).strip() or None

    am = APPLIES_RE.search(section_text)
    if am:
        applies = am.group(1).strip() or None

    return conf, theme, applies


def extract_structured_jtbd(md: str) -> List[ExtractedItem]:
    items: List[ExtractedItem] = []
    for idx, (raw_id, title, section) in enumerate(split_sections(md, JTBD_HEADER_RE), start=1):
        ts, q = extract_best_evidence(section)
        item_id = _normalize_numeric_id("JTBD", raw_id, idx)
        items.append(ExtractedItem(
            id=item_id,
            title=title,
            key=normalize_key(title),
            body=section,
            timestamp=ts,
            quote=q,
        ))
    return items


def extract_structured_insights(md: str) -> List[ExtractedItem]:
    items: List[ExtractedItem] = []
    for idx, (raw_id, title, section) in enumerate(split_sections(md, INS_HEADER_RE), start=1):
        ts, q = extract_best_evidence(section)
        conf, theme, applies = extract_optional_fields(section)
        item_id = _normalize_numeric_id("INS", raw_id, idx)
        items.append(ExtractedItem(
            id=item_id,
            title=title,
            key=normalize_key(title),
            body=section,
            timestamp=ts,
            quote=q,
            confidence=conf,
            theme=theme,
            applies_to=applies,
        ))
    return items


def extract_bullet_only_items(md: str, prefix: str) -> List[ExtractedItem]:
    """
    Fallback: treat each top-level bullet as an item.
    Title is derived from first ~10 words.
    Evidence not available here.
    """
    bullets = [m.group(1).strip() for m in BULLET_LINE_RE.finditer(md)]
    # Ignore placeholder / empty
    bullets = [b for b in bullets if b and "not yet generated" not in b.lower()]

    items: List[ExtractedItem] = []
    for i, b in enumerate(bullets, start=1):
        # Create a short title from the sentence
        words = re.sub(r"\*\*", "", b)
        words = re.sub(r"[^\w\s-]", "", words)
        title = " ".join(words.split()[:10]).strip()
        if not title:
            title = f"{prefix} item {i}"
        item_id = f"{prefix}-{i:03d}"
        items.append(ExtractedItem(
            id=item_id,
            title=title,
            key=normalize_key(title),
            body=b,
            timestamp="",
            quote="",
        ))
    return items


def extract_jtbd_items(jtbd_md: str) -> List[ExtractedItem]:
    structured = extract_structured_jtbd(jtbd_md)
    if structured:
        return structured
    return extract_bullet_only_items(jtbd_md, "JTBD")


def extract_insight_items(ins_md: str) -> List[ExtractedItem]:
    structured = extract_structured_insights(ins_md)
    if structured:
        return structured
    return extract_bullet_only_items(ins_md, "INS")


# ----------------------------
# Aggregation models
# ----------------------------

@dataclass
class Occurrence:
    call_folder: Path
    call_date: str
    timestamp: str
    quote: str


@dataclass
class CanonicalItem:
    title: str
    key: str
    occurrences: List[Occurrence]


def add_occurrence(store: Dict[str, CanonicalItem], item: ExtractedItem, call_folder: Path, call_date: str) -> None:
    occ = Occurrence(
        call_folder=call_folder,
        call_date=call_date,
        timestamp=item.timestamp or "",
        quote=item.quote or "",
    )
    if item.key not in store:
        store[item.key] = CanonicalItem(
            title=item.title,
            key=item.key,
            occurrences=[occ],
        )
    else:
        store[item.key].occurrences.append(occ)


def summarize_occurrences(occurrences: List[Occurrence]) -> Tuple[int, str, str]:
    dates = [o.call_date for o in occurrences if is_iso_date(o.call_date)]
    if not dates:
        return len(occurrences), "unknown-date", "unknown-date"
    dates_sorted = sorted(dates)
    return len(occurrences), dates_sorted[-1], dates_sorted[0]


# ----------------------------
# Writer: customer files
# ----------------------------

def write_calls_md(out_dir: Path, customer_slug: str, calls: List[Tuple[str, Path, str, str]]) -> None:
    lines = [
        f"# Calls — {customer_slug}",
        "",
        "Source of truth for this customer’s call folders.",
        "",
        "| Date | Call folder | Topic | Call type |",
        "|---|---|---|---|",
    ]

    for d, folder, topic, call_type in sorted(calls, key=lambda x: (x[0], x[1].name)):
        rel = relpath_md(out_dir, folder)
        lines.append(f"| {d} | [{folder.name}]({rel}) | `{topic}` | `{call_type}` |")

    write_text(out_dir / "CALLS.md", "\n".join(lines))


def write_jtbd_md(out_dir: Path, customer_slug: str, jtbd_store: Dict[str, CanonicalItem]) -> None:
    header = [
        f"# JTBD — {customer_slug}",
        "",
        "Canonical JTBD list aggregated across calls for this customer.",
        "Each JTBD includes frequency and links back to source calls.",
        "",
    ]
    body: List[str] = []

    items = list(jtbd_store.values())
    items.sort(
        key=lambda it: (summarize_occurrences(it.occurrences)[0], summarize_occurrences(it.occurrences)[1]),
        reverse=True
    )

    for idx, it in enumerate(items, start=1):
        freq, last_seen, first_seen = summarize_occurrences(it.occurrences)
        body.append(f"## JTBD-{idx:03d}: {it.title}")
        body.append(f"- Frequency (calls): {freq}")
        body.append(f"- First seen: {first_seen}")
        body.append(f"- Last seen: {last_seen}")
        body.append("- Evidence (examples):")
        ex = sorted(it.occurrences, key=lambda o: o.call_date, reverse=True)[:3]
        for o in ex:
            rel = relpath_md(out_dir, o.call_folder)
            ts = o.timestamp or "unknown"
            quote = (o.quote or "").strip()
            quote = quote if quote else "_No quote captured in JTBD section._"
            body.append(f"  - [{o.call_folder.name}]({rel}) — {o.call_date} — {ts}")
            body.append(f"    - Quote: {quote}")
        body.append("")

    write_text(out_dir / "JTBD.md", "\n".join(header + body))


def write_insights_md(out_dir: Path, customer_slug: str, ins_store: Dict[str, CanonicalItem]) -> None:
    header = [
        f"# Insights — {customer_slug}",
        "",
        "Canonical insights aggregated across calls for this customer.",
        "Each insight includes frequency, recency, and links to source calls.",
        "",
    ]
    body: List[str] = []

    items = list(ins_store.values())
    items.sort(
        key=lambda it: (summarize_occurrences(it.occurrences)[0], summarize_occurrences(it.occurrences)[1]),
        reverse=True
    )

    for idx, it in enumerate(items, start=1):
        freq, last_seen, first_seen = summarize_occurrences(it.occurrences)
        body.append(f"## INS-{idx:03d}: {it.title}")
        body.append(f"- Frequency (calls): {freq}")
        body.append(f"- First seen: {first_seen}")
        body.append(f"- Last seen: {last_seen}")
        body.append("- Evidence (examples):")
        ex = sorted(it.occurrences, key=lambda o: o.call_date, reverse=True)[:3]
        for o in ex:
            rel = relpath_md(out_dir, o.call_folder)
            ts = o.timestamp or "unknown"
            quote = (o.quote or "").strip()
            quote = quote if quote else "_No quote captured in Insight section._"
            body.append(f"  - [{o.call_folder.name}]({rel}) — {o.call_date} — {ts}")
            body.append(f"    - Quote: {quote}")
        body.append("")

    write_text(out_dir / "INSIGHTS.md", "\n".join(header + body))


def write_customer_overview_md(
    out_dir: Path,
    customer_slug: str,
    customer_name: str,
    calls: List[Tuple[str, Path, str, str]],
    jtbd_store: Dict[str, CanonicalItem],
    ins_store: Dict[str, CanonicalItem],
) -> None:
    num_calls = len(calls)

    def top_titles(store: Dict[str, CanonicalItem], n: int = 5) -> List[str]:
        items = list(store.values())
        items.sort(key=lambda it: summarize_occurrences(it.occurrences)[0], reverse=True)
        return [f"- {it.title} ({summarize_occurrences(it.occurrences)[0]} calls)" for it in items[:n]]

    lines = [
        f"# Customer Overview — {customer_name}",
        "",
        f"- Customer ID: `{customer_slug}`",
        "",
        "This folder is generated by `scripts/update_customer_records.py`.",
        "",
        "## Snapshot",
        f"- Calls processed: {num_calls}",
        f"- Canonical JTBD: {len(jtbd_store)}",
        f"- Canonical insights: {len(ins_store)}",
        "",
        "## Top JTBD (by frequency)",
        *(top_titles(jtbd_store) if jtbd_store else ["- _None extracted yet._"]),
        "",
        "## Top Insights (by frequency)",
        *(top_titles(ins_store) if ins_store else ["- _None extracted yet._"]),
        "",
        "## Source files",
        "- Calls list: `CALLS.md`",
        "- JTBD rollup: `JTBD.md`",
        "- Insights rollup: `INSIGHTS.md`",
    ]
    write_text(out_dir / "CUSTOMER_OVERVIEW.md", "\n".join(lines))


def write_missing_metadata_report(root: Path, missing: List[Tuple[Path, str]]) -> None:
    reg = registry_dir(root)
    reg.mkdir(parents=True, exist_ok=True)
    out = reg / "MISSING_CUSTOMER_METADATA.md"

    lines = [
        "# Missing Customer Metadata",
        "",
        "Calls where `00_metadata.md` is missing `Customer ID` / `Customer` or is still UNKNOWN.",
        "Action: open the call folder, edit `00_metadata.md`, set:",
        "- `- Customer: <Human name>`",
        "- `- Customer ID: <canonical slug>`",
        "",
        "| Call folder | Reason |",
        "|---|---|",
    ]

    for folder, reason in missing:
        lines.append(f"| `{folder.name}` | {reason} |")

    write_text(out, "\n".join(lines))


# ----------------------------
# Main
# ----------------------------

def main() -> None:
    root = repo_root()
    processed = calls_processed_dir(root)
    customers_root = customers_dir(root)

    parser = argparse.ArgumentParser(description="Aggregate call-level JTBD/Insights into per-customer rollups (metadata-driven).")
    parser.add_argument("--only", type=str, default="", help="Only process customers whose slug contains this substring.")
    parser.add_argument("--limit", type=int, default=0, help="Process at most N customers (0 = no limit).")
    parser.add_argument("--dry-run", action="store_true", help="Print what would be written without writing files.")
    args = parser.parse_args()

    if not processed.exists():
        raise SystemExit(f"ERROR: Calls processed folder not found: {processed}")

    grouped_calls: Dict[str, List[Tuple[str, Path, str, str]]] = {}
    customer_names: Dict[str, str] = {}
    missing_meta: List[Tuple[Path, str]] = []

    for folder in sorted([p for p in processed.iterdir() if p.is_dir()]):
        date_str, _candidate_slug, topic_slug = parse_call_folder_name(folder.name)
        ident = resolve_identity_from_metadata(folder)

        customer_slug = safe_slug(ident.customer_id)

        if args.only and args.only.lower() not in customer_slug.lower():
            continue

        grouped_calls.setdefault(customer_slug, []).append((date_str, folder, topic_slug, ident.call_type))
        if customer_slug not in customer_names:
            customer_names[customer_slug] = ident.customer_name if ident.customer_name and ident.customer_name != "UNKNOWN" else customer_slug

        if ident.is_missing:
            missing_meta.append((folder, "Customer metadata missing/UNKNOWN (edit 00_metadata.md)"))

    customers = sorted(grouped_calls.keys())
    if args.limit:
        customers = customers[:args.limit]

    if not customers:
        print("No customers matched.")
        if missing_meta and not args.dry_run:
            write_missing_metadata_report(root, missing_meta)
        return

    for customer_slug in customers:
        calls = grouped_calls[customer_slug]
        out_dir = customers_root / customer_slug
        customer_name = customer_names.get(customer_slug, customer_slug)

        jtbd_store: Dict[str, CanonicalItem] = {}
        ins_store: Dict[str, CanonicalItem] = {}

        for call_date, call_folder, _topic, _call_type in calls:
            jtbd_path = call_folder / "03_ai_jtbd.md"
            ins_path = call_folder / "04_ai_insights.md"

            if jtbd_path.exists():
                jtbd_items = extract_jtbd_items(read_text(jtbd_path))
                for it in jtbd_items:
                    add_occurrence(jtbd_store, it, call_folder, call_date)

            if ins_path.exists():
                ins_items = extract_insight_items(read_text(ins_path))
                for it in ins_items:
                    add_occurrence(ins_store, it, call_folder, call_date)

        if args.dry_run:
            print(f"[DRY RUN] Would write: {out_dir}")
            print(f"  Calls: {len(calls)}, JTBD: {len(jtbd_store)}, Insights: {len(ins_store)}")
            continue

        write_calls_md(out_dir, customer_slug, calls)
        write_jtbd_md(out_dir, customer_slug, jtbd_store)
        write_insights_md(out_dir, customer_slug, ins_store)
        write_customer_overview_md(out_dir, customer_slug, customer_name, calls, jtbd_store, ins_store)

        print(f"Wrote customer rollups: {out_dir.relative_to(root)}")

    if not args.dry_run:
        write_missing_metadata_report(root, missing_meta)

    print("Done.")


if __name__ == "__main__":
    main()
