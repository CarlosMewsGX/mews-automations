#!/usr/bin/env python3
from __future__ import annotations

import argparse
import re
import shutil
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Optional


CHECK_EMOJI = " ✅"


# ----------------------------
# Paths
# ----------------------------

def repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def calls_inbox_dir(root: Path) -> Path:
    # FIX: your actual structure is 01_library/calls/inbox
    return root / "01_library" / "calls" / "inbox"


def calls_processed_dir(root: Path) -> Path:
    return root / "01_library" / "calls" / "processed"


# ----------------------------
# Utilities
# ----------------------------

def safe_slug(s: str) -> str:
    s = s.strip().lower()
    s = s.replace("&", " and ")
    s = re.sub(r"[^a-z0-9]+", "-", s)
    s = re.sub(r"-{2,}", "-", s).strip("-")
    return s or "unknown"


def now_utc_date() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")


def unique_folder(parent: Path, base_name: str) -> Path:
    """
    Create a unique folder path under parent. If exists, append -2, -3, ...
    """
    candidate = parent / base_name
    if not candidate.exists():
        return candidate
    i = 2
    while True:
        c = parent / f"{base_name}-{i}"
        if not c.exists():
            return c
        i += 1


def write_text(p: Path, text: str) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text.rstrip() + "\n", encoding="utf-8")


def read_text(p: Path) -> str:
    return p.read_text(encoding="utf-8", errors="replace")


# ----------------------------
# Naming heuristics (lightweight)
# ----------------------------

def infer_topic_from_filename(name: str) -> str:
    """
    Conservative: turns filename into a topic slug-ish label.
    We don't try to infer customer here—metadata will be truth.
    """
    base = re.sub(r"\.(txt|md)$", "", name, flags=re.IGNORECASE)
    base = base.replace("call-transcript--", "")
    base = base.strip()
    base = re.sub(r"\s+", " ", base)

    if len(base) > 60:
        base = base[:60].rstrip()

    return safe_slug(base) or "call"


def make_call_folder_name(date_str: str, candidate_customer_slug: str, topic_slug: str) -> str:
    return f"{date_str}__{candidate_customer_slug}__{topic_slug}"


# ----------------------------
# Templates
# ----------------------------

def metadata_template(
    date_str: str,
    source_filename: str,
    candidate_customer_slug: str,
) -> str:
    return f"""# Metadata
- Date: {date_str}
- Customer: UNKNOWN
- Customer ID: unknown
- Call type: UNKNOWN   # e.g. discovery | feedback | support | internal
- Participants: UNKNOWN
- Source file: {source_filename}
- Candidate (from filename): {candidate_customer_slug}

## Notes
- Fill in Customer / Customer ID as soon as you can.
- Customer ID should match the canonical folder slug you want in 01_library/customers/.
"""


def transcript_template(raw_transcript: str, source_filename: str) -> str:
    return f"""# Transcript
_Source: `{source_filename}`_

{raw_transcript.strip()}
"""


# ----------------------------
# Ingest
# ----------------------------

@dataclass
class IngestResult:
    ingested: int
    skipped: int
    created_folders: List[Path]


def ingest_one_file(root: Path, txt_path: Path, dry_run: bool) -> Optional[Path]:
    processed = calls_processed_dir(root)
    processed.mkdir(parents=True, exist_ok=True)

    date_str = now_utc_date()
    candidate_customer_slug = "unknown-customer"  # metadata becomes truth

    topic_slug = infer_topic_from_filename(txt_path.name)
    folder_name = make_call_folder_name(date_str, candidate_customer_slug, topic_slug)
    call_folder = unique_folder(processed, folder_name)

    if dry_run:
        print(f"[DRY RUN] Would ingest {txt_path.name} -> {call_folder.name}")
        return call_folder

    call_folder.mkdir(parents=True, exist_ok=False)

    # Move original into call folder (source of truth)
    source_dest = call_folder / "_source_transcript.txt"
    shutil.move(str(txt_path), str(source_dest))

    raw = read_text(source_dest)

    write_text(call_folder / "00_metadata.md", metadata_template(date_str, source_dest.name, candidate_customer_slug))
    write_text(call_folder / "01_transcript.md", transcript_template(raw, source_dest.name))

    # Placeholders (analyze_calls.py overwrites)
    write_text(call_folder / "02_ai_summary.md", "# AI Summary\n\n_Not yet generated._\n")
    write_text(call_folder / "03_ai_jtbd.md", "# Jobs To Be Done (JTBD)\n\n_Not yet generated._\n")
    write_text(call_folder / "04_ai_insights.md", "# Insights\n\n_Not yet generated._\n")
    write_text(call_folder / "05_evidence_clips.md", "# Evidence Clips\n\n_Not yet generated._\n")
    write_text(call_folder / "06_followups.md", "# Follow-ups\n\n_Not yet generated._\n")

    return call_folder


def main() -> None:
    root = repo_root()
    inbox = calls_inbox_dir(root)
    processed = calls_processed_dir(root)

    parser = argparse.ArgumentParser(description="Ingest new transcript .txt files into processed call folder structure.")
    parser.add_argument("--dry-run", action="store_true", help="Show what would be ingested without writing/moving.")
    parser.add_argument("--limit", type=int, default=0, help="Process at most N files (0 = no limit).")
    args = parser.parse_args()

    if not inbox.exists():
        raise SystemExit(f"ERROR: Inbox folder not found: {inbox}")

    processed.mkdir(parents=True, exist_ok=True)

    candidates = sorted([p for p in inbox.iterdir() if p.is_file() and p.suffix.lower() == ".txt"])
    if not candidates:
        print("No .txt transcripts found to ingest.")
        return

    ingested = 0
    skipped = 0

    for p in candidates:
        dest = ingest_one_file(root, p, args.dry_run)
        if dest is None:
            skipped += 1
        else:
            ingested += 1
            print(("Ingested" if not args.dry_run else "Would ingest"), p.name, "->", dest.name)

        if args.limit and ingested >= args.limit:
            break

    print(f"Done. ingested={ingested}, skipped={skipped}")


if __name__ == "__main__":
    main()
