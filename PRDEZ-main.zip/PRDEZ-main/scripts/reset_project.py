#!/usr/bin/env python3
from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path
from typing import List, Tuple


# ----------------------------
# Paths
# ----------------------------

def repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def calls_inbox_dir(root: Path) -> Path:
    return root / "01_library" / "calls" / "inbox"


def calls_processed_dir(root: Path) -> Path:
    return root / "01_library" / "calls" / "processed"


def customers_dir(root: Path) -> Path:
    return root / "01_library" / "customers"


def synthesis_dir(root: Path) -> Path:
    return root / "02_synthesis"


def prds_dir(root: Path) -> Path:
    return root / "03_prds"


# ----------------------------
# Reset Operations
# ----------------------------

def delete_inbox_files(root: Path, dry_run: bool, verbose: bool) -> Tuple[int, List[str]]:
    """Delete all files in inbox directory (preserve directory)."""
    inbox = calls_inbox_dir(root)
    deleted = 0
    actions: List[str] = []
    
    if not inbox.exists():
        if verbose:
            actions.append(f"[SKIP] Inbox directory does not exist: {inbox}")
        return deleted, actions
    
    files = [f for f in inbox.iterdir() if f.is_file()]
    if not files:
        if verbose:
            actions.append(f"[SKIP] Inbox directory is already empty: {inbox}")
        return deleted, actions
    
    for file_path in files:
        if dry_run:
            actions.append(f"[DRY RUN] Would delete: {file_path.name}")
        else:
            try:
                file_path.unlink()
                deleted += 1
                if verbose:
                    actions.append(f"[DELETE] {file_path.name}")
            except Exception as e:
                actions.append(f"[ERROR] Failed to delete {file_path.name}: {e}")
    
    return deleted, actions


def delete_processed_calls(root: Path, dry_run: bool, verbose: bool) -> Tuple[int, List[str]]:
    """Delete all call folders in processed directory (preserve _call_template if exists)."""
    processed = calls_processed_dir(root)
    deleted = 0
    actions: List[str] = []
    
    if not processed.exists():
        if verbose:
            actions.append(f"[SKIP] Processed directory does not exist: {processed}")
        return deleted, actions
    
    folders = [f for f in processed.iterdir() if f.is_dir() and f.name != "_call_template"]
    if not folders:
        if verbose:
            actions.append(f"[SKIP] Processed directory has no call folders (preserving _call_template if exists)")
        return deleted, actions
    
    for folder_path in folders:
        if dry_run:
            actions.append(f"[DRY RUN] Would delete folder: {folder_path.name}")
        else:
            try:
                shutil.rmtree(folder_path)
                deleted += 1
                if verbose:
                    actions.append(f"[DELETE] {folder_path.name}/")
            except Exception as e:
                actions.append(f"[ERROR] Failed to delete {folder_path.name}: {e}")
    
    return deleted, actions


def delete_customer_directories(root: Path, dry_run: bool, verbose: bool) -> Tuple[int, List[str]]:
    """Delete all customer directories including _registry."""
    customers = customers_dir(root)
    deleted = 0
    actions: List[str] = []
    
    if not customers.exists():
        if verbose:
            actions.append(f"[SKIP] Customers directory does not exist: {customers}")
        return deleted, actions
    
    folders = [f for f in customers.iterdir() if f.is_dir()]
    if not folders:
        if verbose:
            actions.append(f"[SKIP] Customers directory is already empty: {customers}")
        return deleted, actions
    
    for folder_path in folders:
        if dry_run:
            actions.append(f"[DRY RUN] Would delete customer folder: {folder_path.name}/")
        else:
            try:
                shutil.rmtree(folder_path)
                deleted += 1
                if verbose:
                    actions.append(f"[DELETE] {folder_path.name}/")
            except Exception as e:
                actions.append(f"[ERROR] Failed to delete {folder_path.name}: {e}")
    
    return deleted, actions


def reset_synthesis_files(root: Path, dry_run: bool, verbose: bool) -> Tuple[int, List[str]]:
    """Delete synthesis content files (preserve README.md)."""
    synthesis = synthesis_dir(root)
    deleted = 0
    actions: List[str] = []
    
    if not synthesis.exists():
        if verbose:
            actions.append(f"[SKIP] Synthesis directory does not exist: {synthesis}")
        return deleted, actions
    
    content_files = [
        "JTBD_CANONICAL.md",
        "INSIGHTS_CANONICAL.md",
        "THEMES.md",
        "CONTRADICTIONS.md",
        "EVIDENCE_GAPS.md",
    ]
    
    for filename in content_files:
        file_path = synthesis / filename
        if not file_path.exists():
            if verbose:
                actions.append(f"[SKIP] File does not exist: {filename}")
            continue
        
        if dry_run:
            actions.append(f"[DRY RUN] Would delete: {filename}")
        else:
            try:
                file_path.unlink()
                deleted += 1
                if verbose:
                    actions.append(f"[DELETE] {filename}")
            except Exception as e:
                actions.append(f"[ERROR] Failed to delete {filename}: {e}")
    
    return deleted, actions


def delete_prd_folders(root: Path, dry_run: bool, verbose: bool) -> Tuple[int, List[str]]:
    """Delete all PRD folders (preserve _templates directory)."""
    prds = prds_dir(root)
    deleted = 0
    actions: List[str] = []
    
    if not prds.exists():
        if verbose:
            actions.append(f"[SKIP] PRDs directory does not exist: {prds}")
        return deleted, actions
    
    folders = [f for f in prds.iterdir() if f.is_dir() and f.name != "_templates"]
    if not folders:
        if verbose:
            actions.append(f"[SKIP] PRDs directory has no PRD folders (preserving _templates)")
        return deleted, actions
    
    for folder_path in folders:
        if dry_run:
            actions.append(f"[DRY RUN] Would delete PRD folder: {folder_path.name}/")
        else:
            try:
                shutil.rmtree(folder_path)
                deleted += 1
                if verbose:
                    actions.append(f"[DELETE] {folder_path.name}/")
            except Exception as e:
                actions.append(f"[ERROR] Failed to delete {folder_path.name}: {e}")
    
    return deleted, actions


def reset_prd_index(root: Path, dry_run: bool, verbose: bool) -> Tuple[bool, List[str]]:
    """Reset PRD_INDEX.md to header-only template."""
    prd_index = prds_dir(root) / "PRD_INDEX.md"
    actions: List[str] = []
    
    template = """# PRD Index

| PRD | Status | Calls | Last Generated (UTC) | Path |
|---|---|---:|---|---|
"""
    
    if not prd_index.exists():
        if verbose:
            actions.append(f"[SKIP] PRD_INDEX.md does not exist: {prd_index}")
        return False, actions
    
    if dry_run:
        actions.append(f"[DRY RUN] Would reset: PRD_INDEX.md")
    else:
        try:
            prd_index.write_text(template, encoding="utf-8")
            if verbose:
                actions.append(f"[RESET] PRD_INDEX.md")
            return True, actions
        except Exception as e:
            actions.append(f"[ERROR] Failed to reset PRD_INDEX.md: {e}")
            return False, actions
    
    return False, actions


# ----------------------------
# Summary and Confirmation
# ----------------------------

def collect_summary(root: Path) -> dict:
    """Collect summary of what would be deleted."""
    summary = {
        "inbox_files": 0,
        "processed_folders": 0,
        "customer_folders": 0,
        "synthesis_files": 0,
        "prd_folders": 0,
        "prd_index_exists": False,
    }
    
    # Count inbox files
    inbox = calls_inbox_dir(root)
    if inbox.exists():
        summary["inbox_files"] = len([f for f in inbox.iterdir() if f.is_file()])
    
    # Count processed folders
    processed = calls_processed_dir(root)
    if processed.exists():
        summary["processed_folders"] = len([f for f in processed.iterdir() if f.is_dir() and f.name != "_call_template"])
    
    # Count customer folders
    customers = customers_dir(root)
    if customers.exists():
        summary["customer_folders"] = len([f for f in customers.iterdir() if f.is_dir()])
    
    # Count synthesis files
    synthesis = synthesis_dir(root)
    if synthesis.exists():
        content_files = ["JTBD_CANONICAL.md", "INSIGHTS_CANONICAL.md", "THEMES.md", "CONTRADICTIONS.md", "EVIDENCE_GAPS.md"]
        summary["synthesis_files"] = len([f for f in content_files if (synthesis / f).exists()])
    
    # Count PRD folders
    prds = prds_dir(root)
    if prds.exists():
        summary["prd_folders"] = len([f for f in prds.iterdir() if f.is_dir() and f.name != "_templates"])
    
    # Check PRD index
    prd_index = prds_dir(root) / "PRD_INDEX.md"
    summary["prd_index_exists"] = prd_index.exists()
    
    return summary


def print_summary(summary: dict) -> None:
    """Print summary of what will be deleted."""
    print("\n" + "=" * 80)
    print("RESET SUMMARY")
    print("=" * 80)
    print(f"  Inbox files:           {summary['inbox_files']}")
    print(f"  Processed call folders: {summary['processed_folders']}")
    print(f"  Customer folders:      {summary['customer_folders']}")
    print(f"  Synthesis files:       {summary['synthesis_files']}")
    print(f"  PRD folders:           {summary['prd_folders']}")
    print(f"  PRD_INDEX.md:          {'Will be reset' if summary['prd_index_exists'] else 'Does not exist'}")
    print("=" * 80)
    
    total = (summary['inbox_files'] + summary['processed_folders'] + 
             summary['customer_folders'] + summary['synthesis_files'] + 
             summary['prd_folders'])
    
    if total == 0 and not summary['prd_index_exists']:
        print("\n✅ Project is already clean. Nothing to reset.")
        return False
    
    print("\n⚠️  This will permanently delete the above items!")
    print("   Templates, scripts, and documentation will be preserved.")
    return True


def confirm_reset(force: bool) -> bool:
    """Prompt for confirmation unless --force is used."""
    if force:
        return True
    
    print("\nProceed with reset? (yes/no): ", end="", flush=True)
    try:
        response = input().strip().lower()
        return response in ("yes", "y")
    except (EOFError, KeyboardInterrupt):
        print("\nCancelled.")
        return False


# ----------------------------
# Main
# ----------------------------

def main() -> None:
    root = repo_root()
    
    parser = argparse.ArgumentParser(
        description="Reset the project to a clean slate by removing all generated content."
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be deleted without making changes."
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Skip confirmation prompt."
    )
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Show detailed output of each deletion."
    )
    args = parser.parse_args()
    
    # Collect summary
    summary = collect_summary(root)
    has_content = print_summary(summary)
    
    if not has_content:
        sys.exit(0)
    
    # Confirm unless --force
    if not confirm_reset(args.force):
        print("\nReset cancelled.")
        sys.exit(2)
    
    # Perform reset operations
    print("\n" + "=" * 80)
    print("RESETTING PROJECT" + (" (DRY RUN)" if args.dry_run else ""))
    print("=" * 80)
    
    all_actions: List[str] = []
    total_deleted = 0
    
    # 1. Delete inbox files
    deleted, actions = delete_inbox_files(root, args.dry_run, args.verbose)
    total_deleted += deleted
    all_actions.extend(actions)
    if not args.verbose and deleted > 0:
        print(f"[{'DRY RUN: ' if args.dry_run else ''}INBOX] Deleted {deleted} file(s)")
    
    # 2. Delete processed call folders
    deleted, actions = delete_processed_calls(root, args.dry_run, args.verbose)
    total_deleted += deleted
    all_actions.extend(actions)
    if not args.verbose and deleted > 0:
        print(f"[{'DRY RUN: ' if args.dry_run else ''}PROCESSED] Deleted {deleted} folder(s)")
    
    # 3. Delete customer directories
    deleted, actions = delete_customer_directories(root, args.dry_run, args.verbose)
    total_deleted += deleted
    all_actions.extend(actions)
    if not args.verbose and deleted > 0:
        print(f"[{'DRY RUN: ' if args.dry_run else ''}CUSTOMERS] Deleted {deleted} folder(s)")
    
    # 4. Reset synthesis files
    deleted, actions = reset_synthesis_files(root, args.dry_run, args.verbose)
    total_deleted += deleted
    all_actions.extend(actions)
    if not args.verbose and deleted > 0:
        print(f"[{'DRY RUN: ' if args.dry_run else ''}SYNTHESIS] Deleted {deleted} file(s)")
    
    # 5. Delete PRD folders
    deleted, actions = delete_prd_folders(root, args.dry_run, args.verbose)
    total_deleted += deleted
    all_actions.extend(actions)
    if not args.verbose and deleted > 0:
        print(f"[{'DRY RUN: ' if args.dry_run else ''}PRDS] Deleted {deleted} folder(s)")
    
    # 6. Reset PRD index
    reset, actions = reset_prd_index(root, args.dry_run, args.verbose)
    all_actions.extend(actions)
    if not args.verbose and reset:
        print(f"[{'DRY RUN: ' if args.dry_run else ''}PRD_INDEX] Reset to template")
    
    # Print verbose output if requested
    if args.verbose:
        print("\n" + "=" * 80)
        print("DETAILED ACTIONS")
        print("=" * 80)
        for action in all_actions:
            print(f"  {action}")
    
    # Final summary
    print("\n" + "=" * 80)
    if args.dry_run:
        print("✅ DRY RUN COMPLETE")
        print(f"   Would delete/reset {total_deleted} item(s)")
    else:
        print("✅ RESET COMPLETE")
        print(f"   Deleted/reset {total_deleted} item(s)")
    print("=" * 80)
    print("\nPreserved:")
    print("  - Scripts in scripts/")
    print("  - Templates in 03_prds/_templates/")
    print("  - Call template in 01_library/calls/_call_template/ (if exists)")
    print("  - Documentation files (README.md, USER_CONTEXT.md, etc.)")


if __name__ == "__main__":
    main()
