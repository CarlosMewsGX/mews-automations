#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path
from typing import List, Optional, Tuple

from azure_openai_client import load_env_file


# ----------------------------
# Repo paths
# ----------------------------

def repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def scripts_dir(root: Path) -> Path:
    return root / "scripts"


def calls_inbox(root: Path) -> Path:
    return root / "01_library" / "calls" / "inbox"


def calls_processed(root: Path) -> Path:
    return root / "01_library" / "calls" / "processed"


# ----------------------------
# Subprocess runner
# ----------------------------

def run_step(
    title: str,
    cmd: List[str],
    cwd: Path,
    env: Optional[dict] = None,
    allow_fail: bool = False,
) -> Tuple[int, str]:
    """
    Runs a step and returns (exit_code, combined_output).
    Streams output live to terminal (so you get progress).
    """
    print("\n" + "=" * 80)
    print(f"STEP: {title}")
    print("CMD:  " + " ".join(cmd))
    print("=" * 80)

    # Stream output live
    p = subprocess.Popen(
        cmd,
        cwd=str(cwd),
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
        universal_newlines=True,
    )

    out_lines: List[str] = []
    assert p.stdout is not None
    for line in p.stdout:
        print(line, end="")
        out_lines.append(line)

    p.wait()
    code = p.returncode
    combined = "".join(out_lines)

    if code != 0 and not allow_fail:
        print("\n" + "!" * 80)
        print(f"FAILED: {title} (exit code {code})")
        print("!" * 80)
        raise SystemExit(code)

    print(f"\nOK: {title} (exit code {code})")
    return code, combined


# ----------------------------
# Main
# ----------------------------

def main() -> None:
    root = repo_root()
    sdir = scripts_dir(root)

    parser = argparse.ArgumentParser(
        description="Run the full PRDEZ pipeline: ingest -> analyze -> customer rollups -> synthesis"
    )
    parser.add_argument("--limit", type=int, default=0, help="Max number of call folders to analyze (0 = no limit).")
    parser.add_argument("--only", type=str, default="", help="Only analyze call folders whose name contains this substring.")
    parser.add_argument("--force", action="store_true", help="Force re-analyze even if ANALYZED.flag exists.")
    parser.add_argument("--dry-run", action="store_true", help="Run in dry-run mode where supported.")
    parser.add_argument("--skip-ingest", action="store_true", help="Skip ingest step.")
    parser.add_argument("--skip-analyze", action="store_true", help="Skip analyze step.")
    parser.add_argument("--skip-customers", action="store_true", help="Skip update_customer_records step.")
    parser.add_argument("--skip-synthesis", action="store_true", help="Skip synthesis step.")
    args = parser.parse_args()

    # Basic structure checks (fail fast with helpful messages)
    inbox = calls_inbox(root)
    processed = calls_processed(root)

    if not inbox.exists():
        raise SystemExit(f"ERROR: Inbox folder not found: {inbox}\nExpected: 01_library/calls/inbox")
    if not processed.exists():
        raise SystemExit(f"ERROR: Processed folder not found: {processed}\nExpected: 01_library/calls/processed")
    if not sdir.exists():
        raise SystemExit(f"ERROR: Scripts folder not found: {sdir}")

    load_env_file(root)

    # Ensure Azure OpenAI variables are available for analyze step.
    # (We do not validate here beyond presence; analyze_calls.py will enforce.)
    if not args.skip_analyze:
        missing = [
            name
            for name in (
                "AZURE_OPENAI_ENDPOINT",
                "AZURE_OPENAI_API_KEY",
                "AZURE_OPENAI_API_VERSION",
                "AZURE_OPENAI_DEPLOYMENT",
            )
            if not os.getenv(name)
        ]
        if missing:
            raise SystemExit(f"ERROR: Missing Azure OpenAI environment values: {', '.join(missing)}")

    py = sys.executable  # use current python interpreter (venv-safe)

    # 1) Ingest
    if not args.skip_ingest:
        ingest_path = sdir / "ingest_calls.py"
        if not ingest_path.exists():
            raise SystemExit(f"ERROR: Missing script: {ingest_path}")

        ingest_cmd = [py, str(ingest_path)]
        if args.dry_run:
            ingest_cmd.append("--dry-run")

        run_step("Ingest new transcripts (inbox -> processed)", ingest_cmd, cwd=root)

    # 2) Analyze
    if not args.skip_analyze:
        analyze_path = sdir / "analyze_calls.py"
        if not analyze_path.exists():
            raise SystemExit(f"ERROR: Missing script: {analyze_path}")

        analyze_cmd = [py, str(analyze_path)]
        if args.force:
            analyze_cmd.append("--force")
        if args.dry_run:
            analyze_cmd.append("--dry-run")
        if args.limit and args.limit > 0:
            analyze_cmd += ["--limit", str(args.limit)]
        if args.only:
            analyze_cmd += ["--only", args.only]

        run_step("Analyze call folders (Azure OpenAI extraction)", analyze_cmd, cwd=root)

    # 3) Update customer records
    if not args.skip_customers:
        cust_path = sdir / "update_customer_records.py"
        if not cust_path.exists():
            raise SystemExit(f"ERROR: Missing script: {cust_path}")

        cust_cmd = [py, str(cust_path)]
        if args.dry_run:
            cust_cmd.append("--dry-run")
        # NOTE: update_customer_records.py supports --only/--limit in your current version.
        if args.limit and args.limit > 0:
            cust_cmd += ["--limit", str(args.limit)]
        if args.only:
            # Here --only means "only customers containing substring"
            cust_cmd += ["--only", args.only]

        run_step("Update customer rollups (per-customer JTBD/Insights)", cust_cmd, cwd=root)

    # 4) Build synthesis
    if not args.skip_synthesis:
        synth_path = sdir / "build_synthesis.py"
        if not synth_path.exists():
            raise SystemExit(f"ERROR: Missing script: {synth_path}")

        synth_cmd = [py, str(synth_path)]
        if args.dry_run:
            synth_cmd.append("--dry-run")
        if args.only:
            synth_cmd += ["--only", args.only]
        if args.limit and args.limit > 0:
            synth_cmd += ["--limit", str(args.limit)]

        run_step("Build synthesis (cross-customer trends)", synth_cmd, cwd=root)

    print("\n✅ Pipeline complete.")
    print(f"- Inbox:     {inbox.relative_to(root)}")
    print(f"- Processed: {processed.relative_to(root)}")
    print(f"- Customers: {(root / '01_library' / 'customers').relative_to(root)}")
    print(f"- Synthesis: {(root / '02_synthesis').relative_to(root)}")


if __name__ == "__main__":
    main()
