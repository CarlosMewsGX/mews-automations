#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from azure_openai_client import AzureOpenAIClient, load_azure_openai_config
from user_context import USER_CONTEXT_FILENAME, format_user_context_for_prompt, load_user_context


# ============================
# CONFIG
# ============================

PRDS_ROOT = Path("03_prds")
TEMPLATES_DIR = PRDS_ROOT / "_templates"

# ✅ Back to the original contract
PRIMARY_INPUT_FILE = "01_scope.md"

# ✅ Backwards-compatible aliases (so renames don't break you)
INPUT_ALIASES = ["01_scope.md", "01_inputs.md"]

PRD_OUT_FILE = "00_prd.md"
RESEARCH_GUIDE_FILE = "02_research_guide.md"
RESEARCH_SUMMARY_FILE = "03_research_summary.md"
KEY_JTBD_FILE = "04_key_jtbd.md"
KEY_INSIGHTS_FILE = "05_key_insights.md"

RUNLOG = "ai_prd_run.json"
RAW = "ai_prd_raw_response.txt"


# ============================
# UTIL
# ============================

def repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def read_text(p: Path) -> str:
    return p.read_text(encoding="utf-8", errors="replace")


def write_text(p: Path, text: str) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text.rstrip() + "\n", encoding="utf-8")


def now_utc_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def safe_slug(s: str) -> str:
    s = s.strip().lower()
    s = s.replace("&", " and ")
    s = re.sub(r"[^a-z0-9]+", "-", s)
    s = re.sub(r"-{2,}", "-", s).strip("-")
    return s or "unknown"


def rel(base: Path, p: Path) -> str:
    return str(p.relative_to(base)).replace("\\", "/")


def find_inputs_file(prd_dir: Path) -> Optional[Path]:
    for name in INPUT_ALIASES:
        p = prd_dir / name
        if p.exists():
            return p
    return None


# ============================
# PROMPT
# ============================

def build_prompt(
    prd_template: str,
    scope_md: str,
    research_guide_md: str,
    research_summary_md: str,
    key_jtbd_md: str,
    key_insights_md: str,
    user_context: str,
) -> str:
    # Full replacement prompt: more descriptive PRDs without inventing facts.
    context_block = format_user_context_for_prompt(user_context)

    return f"""
You are a Senior Product Manager writing a decision-grade PRD.

You will output EXACTLY ONE Markdown PRD document.

NON-NEGOTIABLE RULES:
- Use ONLY the provided materials: PRD template + PRD folder research outputs below.
- Do NOT invent customer facts, quotes, numbers, company names, timelines, or technical capabilities.
- If something is unknown, write "TBD" — but avoid "TBD" when a directional statement is possible
  (e.g., "within current dashboard performance envelope", "inherits existing permissions").
- Preserve the PRD template structure and headings EXACTLY.
- Output must be valid Markdown.
- Do NOT wrap the output in triple backticks.
- Do NOT add extra sections not present in the template.
  (If you need narrative and the template lacks it, embed narrative content into Summary and/or Problem Statement.)

WRITING STYLE (slightly more verbose than a skeleton, still crisp):
- Prefer bullets; short paragraphs are allowed when needed for clarity.
- Add 1–2 concrete sentences where ambiguity commonly occurs
  (especially Summary, Problem Statement, Solution Outline, and Rollout/GA criteria).
- Avoid generic phrases like "improve experience" without stating what changes for the user.
- Use concrete consequences (e.g., "forces spreadsheet export", "erodes trust", "blocks adoption")
  ONLY if supported by the provided research.

GROUNDING REQUIREMENTS:
- Anchor every major claim in the Key Insights / JTBD / Research Summary provided.
- When referencing research, cite explicitly using the identifiers present in the inputs
  (e.g., "JTBD-07", "Insight-10"). Do not invent new insight numbers/titles.
- If multiple insights conflict, reflect the uncertainty and list it as an Open Question.
{context_block}

CONTENT REQUIREMENTS (how to fill key sections):
1) Summary:
- 5–8 sentences.
- Must include: user + problem + business impact + what we’re proposing + why now.
- Add ONE sentence explaining why the problem is non-trivial (e.g., data-model mismatch, reconciliation complexity),
  grounded in the provided research.

2) Problem Statement:
- Be explicit about the root cause AND the consequence (what users do instead, what breaks, why trust is lost).
- Use JTBD and Insight references where they strengthen credibility.

3) Users & Use Cases:
- For each primary persona, add one line of context: what they own + why they care.
- Top use cases should be phrased as user stories and map to at least one Insight or JTBD when possible.

4) Scope:
- In scope and out of scope items should each include a short rationale phrase (why included/excluded),
  grounded in research or constraints.

5) Solution Outline:
- Keep this high-level but opinionated and testable.
- UX/workflow: describe how users access/choose the new capability and whether the choice persists.
- Data model/definitions: define key terms and the aggregation level. Call out what MUST NOT happen (e.g., double-counting).
- Permissions/governance + Export/interop: if unknown, state a default assumption ("inherits existing") unless research indicates otherwise.

6) Requirements:
- Functional requirements must be verifiable.
- Add at least one reconciliation requirement when metrics exist, if supported by the problem statement
  (e.g., "must reconcile with underlying reservation/availability data at day/dorm level").
- Non-functional requirements: replace "TBD" with directional targets when safe:
  - Performance: "same envelope as existing dashboards" unless inputs specify otherwise.
  - Auditability: "documented logic + traceability to underlying data" unless inputs specify otherwise.

7) Success Metrics:
- Use measurable signals where possible; if only qualitative is available, say how it will be validated
  (beta interviews, tagged support tickets, etc.).
- Avoid made-up baselines/targets unless provided. Use %/delta only if grounded in inputs; otherwise define the metric.

8) Rollout Plan:
- Beta: define who, why them, and what you will validate.
- GA criteria: explicit and testable (e.g., "reconciliation tests pass across representative configurations",
  "no increase in accuracy-related tickets"), without inventing thresholds.
- Migration/backwards compatibility: state the expected default (e.g., existing views unchanged) unless research indicates a breaking change.

9) Risks & Assumptions / Open Questions:
- Risks should be concrete and tied to execution.
- Open Questions should be decisions or unknowns that block scoping, definition, or correctness.

FINAL QUALITY CHECK BEFORE YOU OUTPUT:
- No empty sections unless truly unknown (then "TBD" with one line describing what’s needed to resolve it).
- Each of Goals, Scope, Requirements, Success Metrics has at least 2–3 meaningful bullets.
- Every metric introduced has a short definition or calculation note somewhere in Solution Outline or Requirements.
- Avoid "TBD" clusters: no more than ~2 TBDs per section unless the inputs truly lack coverage. If more, summarize what info is missing.

PRD TEMPLATE (must preserve structure and headings):
{prd_template}

PRD SCOPE (calls included):
{scope_md}

RESEARCH GUIDE (optional context):
{research_guide_md}

RESEARCH SUMMARY (call-level summary excerpts):
{research_summary_md}

KEY JTBD (ranked):
{key_jtbd_md}

KEY INSIGHTS (ranked):
{key_insights_md}
""".strip()


# ============================
# GENERATE ONE PRD
# ============================

def generate_one(prd_slug: str, temperature: float, force: bool, dry_run: bool) -> None:
    root = repo_root()
    user_context = load_user_context(root)
    prd_dir = root / PRDS_ROOT / prd_slug

    if not prd_dir.exists():
        raise SystemExit(f"ERROR: PRD folder not found: {prd_dir}")

    template_path = root / TEMPLATES_DIR / "PRD_TEMPLATE.md"
    if not template_path.exists():
        raise SystemExit(f"ERROR: Missing template: {template_path}")

    scope_path = find_inputs_file(prd_dir)
    if not scope_path:
        raise SystemExit(
            "ERROR: Missing PRD scope/inputs file.\n"
            f"Looked for: {', '.join(INPUT_ALIASES)}\n"
            f"Expected one of those in: {prd_dir}"
        )

    # These should exist if generate_prd.py has run
    rs_path = prd_dir / RESEARCH_SUMMARY_FILE
    jtbd_path = prd_dir / KEY_JTBD_FILE
    ins_path = prd_dir / KEY_INSIGHTS_FILE

    missing = [p.name for p in (rs_path, jtbd_path, ins_path) if not p.exists()]
    if missing:
        raise SystemExit(
            "ERROR: Missing generated research files. Run generate_prd.py first.\n"
            f"Missing: {', '.join(missing)}"
        )

    out_path = prd_dir / PRD_OUT_FILE
    if out_path.exists() and not force:
        print(f"[SKIP] {out_path} exists. Use --force to overwrite.")
        return

    prd_template = read_text(template_path)
    scope_md = read_text(scope_path)
    research_summary_md = read_text(rs_path)
    key_jtbd_md = read_text(jtbd_path)
    key_insights_md = read_text(ins_path)

    rg_path = prd_dir / RESEARCH_GUIDE_FILE
    research_guide_md = read_text(rg_path) if rg_path.exists() else "TBD (no research guide file present)."

    prompt = build_prompt(
        prd_template=prd_template,
        scope_md=scope_md,
        research_guide_md=research_guide_md,
        research_summary_md=research_summary_md,
        key_jtbd_md=key_jtbd_md,
        key_insights_md=key_insights_md,
        user_context=user_context,
    )

    if dry_run:
        print(f"[DRY RUN] Would generate {rel(root, out_path)} using Azure OpenAI")
        return

    config = load_azure_openai_config(root)
    client = AzureOpenAIClient(config)

    raw = client.generate(prompt, temperature)
    write_text(prd_dir / RAW, raw)

    if len(raw.strip()) < 300:
        raise RuntimeError("PRD generation returned too little content.")
    if raw.lstrip().startswith("```"):
        raise RuntimeError("PRD output was wrapped in backticks; refusing to write.")

    write_text(out_path, raw)

    write_text(
        prd_dir / RUNLOG,
        json.dumps(
            {
                "model": client.config.deployment,
                "api_version": client.config.api_version,
                "temperature": temperature,
                "ran_at": now_utc_iso(),
                "prompt_chars": len(prompt),
                "response_chars": len(raw),
                "user_context_chars": len(user_context),
                "user_context_path": str(root / USER_CONTEXT_FILENAME) if user_context else None,
                "template": str(template_path),
                "scope_file_used": str(scope_path),
                "research_files": {
                    "research_summary": str(rs_path),
                    "key_jtbd": str(jtbd_path),
                    "key_insights": str(ins_path),
                    "research_guide": str(rg_path) if rg_path.exists() else None,
                },
                "output": str(out_path),
            },
            indent=2,
        ),
    )

    print(f"[WRITE] {rel(root, out_path)}")
    print(f"[LOG]   {rel(root, prd_dir / RUNLOG)}")
    print(f"[RAW]   {rel(root, prd_dir / RAW)}")


# ============================
# ENTRY POINT
# ============================

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Generate 00_prd.md using Azure OpenAI, based on PRD template + generated PRD research outputs."
    )
    parser.add_argument("--prd", type=str, default="", help="PRD slug under 03_prds/<prd-slug> to generate.")
    parser.add_argument("--all", action="store_true", help="Generate for all PRDs with scope + generated research files.")
    parser.add_argument("--temperature", type=float, default=0.2)
    parser.add_argument("--force", action="store_true", help="Overwrite 00_prd.md if it exists.")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    root = repo_root()
    prds_root = root / PRDS_ROOT
    if not prds_root.exists():
        raise SystemExit(f"ERROR: PRD root not found: {prds_root}")

    if args.all and args.prd:
        raise SystemExit("ERROR: Use either --prd <slug> OR --all, not both.")

    if args.all:
        for p in sorted(prds_root.iterdir()):
            if not p.is_dir():
                continue
            if p.name.startswith("_"):
                continue

            scope_path = find_inputs_file(p)
            if not scope_path:
                continue

            if not (p / RESEARCH_SUMMARY_FILE).exists():
                continue
            if not (p / KEY_JTBD_FILE).exists():
                continue
            if not (p / KEY_INSIGHTS_FILE).exists():
                continue

            print("\n" + "=" * 80)
            print(f"PRD: {p.name}")
            print("=" * 80)
            generate_one(p.name, args.temperature, args.force, args.dry_run)

        print("\nDone.")
        return

    if not args.prd:
        raise SystemExit("ERROR: Missing --prd <prd-slug> (or use --all).")

    slug = safe_slug(args.prd)
    generate_one(slug, args.temperature, args.force, args.dry_run)
    print("\nDone.")


if __name__ == "__main__":
    main()
