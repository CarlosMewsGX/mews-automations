#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import re
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple


# ============================
# PATHS
# ============================

def repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def customers_root(root: Path) -> Path:
    return root / "01_library" / "customers"


def synthesis_root(root: Path) -> Path:
    return root / "02_synthesis"


def relpath_md(from_dir: Path, to_path: Path) -> str:
    # Works across sibling dirs (customers ↔ calls)
    return os.path.relpath(to_path, start=from_dir).replace("\\", "/")


# ============================
# UTIL
# ============================

def read_text(p: Path) -> str:
    return p.read_text(encoding="utf-8", errors="replace")


def write_text(p: Path, text: str) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text.rstrip() + "\n", encoding="utf-8")


def normalize_key(s: str) -> str:
    s = s.strip().lower()
    s = re.sub(r"\s+", " ", s)
    s = re.sub(r"[^\w\s-]", "", s)
    return s


def is_iso_date(d: str) -> bool:
    try:
        datetime.strptime(d, "%Y-%m-%d")
        return True
    except Exception:
        return False


def merge_dates(existing: str, new: str, mode: str) -> str:
    """
    mode: 'min' for first_seen, 'max' for last_seen
    """
    if not is_iso_date(existing):
        return new if is_iso_date(new) else existing
    if not is_iso_date(new):
        return existing
    if mode == "min":
        return min(existing, new)
    return max(existing, new)


# ============================
# PARSING CUSTOMER ROLLUPS
# (accounts for metadata-driven customers + internal/unknown)
# ============================

H2_RE = re.compile(r"^##\s+", re.MULTILINE)
JTBD_H2_RE = re.compile(r"^##\s+JTBD-\d+:\s*(.+?)\s*$", re.MULTILINE)
INS_H2_RE = re.compile(r"^##\s+INS-\d+:\s*(.+?)\s*$", re.MULTILINE)

FREQ_RE = re.compile(r"^\s*-\s*Frequency\s*\(calls\):\s*(\d+)\s*$", re.MULTILINE)
FIRST_SEEN_RE = re.compile(r"^\s*-\s*First seen:\s*(.+?)\s*$", re.MULTILINE)
LAST_SEEN_RE = re.compile(r"^\s*-\s*Last seen:\s*(.+?)\s*$", re.MULTILINE)

# Your rollups render quotes as: "    - Quote: ..."
QUOTE_RE = re.compile(r"^\s*-\s*Quote:\s*(.+?)\s*$", re.MULTILINE)

# In calls table we now have: | Date | Call folder | Topic | Call type |
CALLS_ROW_RE = re.compile(r"^\|\s*([0-9]{4}-[0-9]{2}-[0-9]{2}|unknown-date)\s*\|\s*\[(.+?)\]\((.+?)\)\s*\|\s*`(.*?)`\s*\|\s*`(.*?)`\s*\|\s*$")


def split_by_h2(md: str) -> List[str]:
    """
    Split markdown into H2 sections. Each returned section includes the H2 header line.
    """
    starts = [m.start() for m in H2_RE.finditer(md)]
    if not starts:
        return []
    sections = []
    for i, s in enumerate(starts):
        e = starts[i + 1] if i + 1 < len(starts) else len(md)
        sections.append(md[s:e].strip())
    return sections


@dataclass
class RollupItem:
    title: str
    key: str
    freq_calls: int
    first_seen: str
    last_seen: str
    quote_count: int
    quotes_preview: List[str]


def parse_rollup(md: str, kind: str) -> List[RollupItem]:
    """
    kind: 'jtbd' or 'insight'
    """
    items: List[RollupItem] = []
    for sec in split_by_h2(md):
        head = sec.splitlines()[0].strip()

        if kind == "jtbd":
            m = JTBD_H2_RE.match(head)
        else:
            m = INS_H2_RE.match(head)

        if not m:
            continue

        title = m.group(1).strip()
        key = normalize_key(title)

        fm = FREQ_RE.search(sec)
        freq = int(fm.group(1)) if fm else 1

        fs = FIRST_SEEN_RE.search(sec)
        ls = LAST_SEEN_RE.search(sec)
        first_seen = fs.group(1).strip() if fs else "unknown-date"
        last_seen = ls.group(1).strip() if ls else "unknown-date"

        quotes = [q.group(1).strip() for q in QUOTE_RE.finditer(sec)]
        real_quotes = [q for q in quotes if q and "no quote captured" not in q.lower()]
        quote_count = len(real_quotes)
        quotes_preview = real_quotes[:2]

        items.append(RollupItem(
            title=title,
            key=key,
            freq_calls=freq,
            first_seen=first_seen,
            last_seen=last_seen,
            quote_count=quote_count,
            quotes_preview=quotes_preview,
        ))

    return items


@dataclass
class CustomerCallLink:
    date: str
    call_folder_name: str
    call_rel_link: str
    topic: str
    call_type: str


def parse_calls_md(md: str) -> List[CustomerCallLink]:
    links: List[CustomerCallLink] = []
    for line in md.splitlines():
        m = CALLS_ROW_RE.match(line.strip())
        if not m:
            continue
        date, folder_name, rel_link, topic, call_type = m.groups()
        links.append(CustomerCallLink(
            date=date.strip(),
            call_folder_name=folder_name.strip(),
            call_rel_link=rel_link.strip(),
            topic=topic.strip(),
            call_type=call_type.strip(),
        ))
    return links


# ============================
# SYNTHESIS MODEL
# ============================

@dataclass
class SynthItem:
    title: str
    key: str
    customer_count: int = 0
    call_count: int = 0
    first_seen: str = "unknown-date"
    last_seen: str = "unknown-date"
    customers: List[str] = field(default_factory=list)
    quotes_preview: List[str] = field(default_factory=list)
    quote_coverage_customers: int = 0
    quote_customers: Set[str] = field(default_factory=set)
    # helpful for drill-down
    customer_calltype_counts: Dict[str, int] = field(default_factory=dict)


def add_to_synth(
    store: Dict[str, SynthItem],
    item: RollupItem,
    customer_id: str,
    call_types_for_customer: List[str],
) -> None:
    if item.key not in store:
        store[item.key] = SynthItem(title=item.title, key=item.key)

    s = store[item.key]

    # customer occurrence
    if customer_id not in s.customers:
        s.customers.append(customer_id)
        s.customer_count += 1

    # call counts
    s.call_count += item.freq_calls

    # dates
    s.first_seen = merge_dates(s.first_seen, item.first_seen, "min")
    s.last_seen = merge_dates(s.last_seen, item.last_seen, "max")

    # quote coverage and snippets
    if item.quote_count > 0:
        s.quote_customers.add(customer_id)
        s.quote_coverage_customers = len(s.quote_customers)
    for q in item.quotes_preview:
        if q and q not in s.quotes_preview and len(s.quotes_preview) < 5:
            s.quotes_preview.append(q)

    # call types distribution (rough: per customer, not per item)
    unique_call_types = {ct for ct in call_types_for_customer if ct}
    for ct in unique_call_types:
        s.customer_calltype_counts[ct] = s.customer_calltype_counts.get(ct, 0) + 1


def aggregate_calltype_totals(stores: List[Dict[str, SynthItem]]) -> Dict[str, int]:
    totals: Dict[str, int] = {}
    for store in stores:
        for s in store.values():
            for ct, count in s.customer_calltype_counts.items():
                totals[ct] = totals.get(ct, 0) + count
    return totals


# ============================
# THEMES / HEURISTICS
# ============================

THEME_BUCKETS = {
    "Finance & Invoicing": ["invoice", "proforma", "chargeback", "payout", "settlement", "fee", "payment", "vat"],
    "Revenue & Pricing": ["rate", "adr", "revpar", "pickup", "pace", "segment", "voucher", "pricing"],
    "Operations": ["housekeeping", "maintenance", "tasks", "ops", "front desk", "availability", "blocks", "blocked"],
    "Reporting & Self-serve": ["report", "dashboard", "pivot", "export", "excel", "self-service", "custom", "drag"],
    "Data Quality & Definitions": ["definition", "reconcile", "mismatch", "timezone", "currency", "logic", "incorrect"],
    "Integrations & Data Sources": ["connector", "integration", "power bi", "api", "third-party", "hr", "marketing"],
}

CONTRADICTION_PAIRS = [
    ("self-serve", "guided"),
    ("custom", "out-of-the-box"),
    ("export", "in-tool"),
    ("real-time", "batched"),
    ("centralized", "embedded"),
]


def bucket_for_title(title: str) -> List[str]:
    t = title.lower()
    buckets = []
    for b, kws in THEME_BUCKETS.items():
        if any(kw in t for kw in kws):
            buckets.append(b)
    return buckets or ["Uncategorized"]


# ============================
# WRITERS
# ============================

def write_canonical_md(out_dir: Path, filename: str, heading: str, store: Dict[str, SynthItem]) -> None:
    items = list(store.values())
    items.sort(key=lambda s: (s.customer_count, s.call_count, s.last_seen), reverse=True)

    lines: List[str] = [
        f"# {heading}",
        "",
        "Ranked by number of customers, then number of calls, then recency.",
        "",
        "| Rank | Item | Customers | Calls | First seen | Last seen | Quote coverage |",
        "|---:|---|---:|---:|---|---|---:|",
    ]

    for i, s in enumerate(items, start=1):
        lines.append(
            f"| {i} | {s.title} | {s.customer_count} | {s.call_count} | {s.first_seen} | {s.last_seen} | {s.quote_coverage_customers} |"
        )

    lines.append("")
    lines.append("## Details (top 25)")
    lines.append("")

    for s in items[:25]:
        lines.append(f"### {s.title}")
        lines.append(f"- Customers ({s.customer_count}): {', '.join(sorted(s.customers))}")
        lines.append(f"- Calls (sum): {s.call_count}")
        lines.append(f"- First seen: {s.first_seen}")
        lines.append(f"- Last seen: {s.last_seen}")
        if s.quotes_preview:
            lines.append("- Quote snippets:")
            for q in s.quotes_preview[:5]:
                lines.append(f"  - {q}")
        lines.append("")

    write_text(out_dir / filename, "\n".join(lines))


def write_themes_md(out_dir: Path, jtbd: Dict[str, SynthItem], ins: Dict[str, SynthItem]) -> None:
    buckets: Dict[str, Dict[str, List[SynthItem]]] = {}
    for store_name, store in [("JTBD", jtbd), ("Insights", ins)]:
        for s in store.values():
            for b in bucket_for_title(s.title):
                buckets.setdefault(b, {}).setdefault(store_name, []).append(s)

    lines: List[str] = [
        "# Themes",
        "",
        "Auto-bucketed using simple keyword rules. Treat as a starting point.",
        "",
    ]

    for b in sorted(buckets.keys()):
        lines.append(f"## {b}")
        for store_name in ["JTBD", "Insights"]:
            items = buckets[b].get(store_name, [])
            if not items:
                continue
            items.sort(key=lambda s: (s.customer_count, s.call_count, s.last_seen), reverse=True)
            lines.append(f"### {store_name} (top 10)")
            for s in items[:10]:
                lines.append(f"- {s.title} — {s.customer_count} customers, {s.call_count} calls (last: {s.last_seen})")
            lines.append("")
        lines.append("")

    write_text(out_dir / "THEMES.md", "\n".join(lines))


def write_contradictions_md(out_dir: Path, jtbd: Dict[str, SynthItem], ins: Dict[str, SynthItem]) -> None:
    all_titles = [s.title.lower() for s in list(jtbd.values()) + list(ins.values())]

    found: List[Tuple[str, str]] = []
    for a, b in CONTRADICTION_PAIRS:
        has_a = any(a in t for t in all_titles)
        has_b = any(b in t for t in all_titles)
        if has_a and has_b:
            found.append((a, b))

    lines: List[str] = [
        "# Contradictions",
        "",
        "Heuristic flags where opposing keywords both appear in the corpus.",
        "Use this to guide deeper review, not as proof of contradiction.",
        "",
    ]

    if not found:
        lines.append("- No contradiction keyword pairs detected.")
        write_text(out_dir / "CONTRADICTIONS.md", "\n".join(lines))
        return

    for a, b in found:
        lines.append(f"## {a} ↔ {b}")
        lines.append("- Related items (sample):")
        matches = [t for t in all_titles if a in t or b in t]
        for t in matches[:12]:
            lines.append(f"  - {t}")
        lines.append("")

    write_text(out_dir / "CONTRADICTIONS.md", "\n".join(lines))


def write_evidence_gaps_md(out_dir: Path, ins: Dict[str, SynthItem]) -> None:
    items = list(ins.values())
    gaps = [s for s in items if s.customer_count >= 2 and s.quote_coverage_customers <= 1]
    gaps.sort(key=lambda s: (s.customer_count, s.call_count), reverse=True)

    lines: List[str] = [
        "# Evidence Gaps",
        "",
        "Items that recur across customers but have weak captured quote coverage in rollups.",
        "Action: ensure future calls capture direct quotes (or tighten extractor prompts).",
        "",
    ]

    if not gaps:
        lines.append("- No obvious evidence gaps detected by this heuristic.")
        write_text(out_dir / "EVIDENCE_GAPS.md", "\n".join(lines))
        return

    lines.append("| Insight | Customers | Calls | Quote coverage | Last seen |")
    lines.append("|---|---:|---:|---:|---|")
    for s in gaps[:50]:
        lines.append(f"| {s.title} | {s.customer_count} | {s.call_count} | {s.quote_coverage_customers} | {s.last_seen} |")

    lines.append("")
    lines.append("## Suggested follow-ups")
    lines.append("- For top recurring insights, ensure the per-call extractor captures at least one verbatim quote.")
    lines.append("- If quotes exist in transcripts but aren’t captured, tighten `analyze_calls.py` to require quotes for top insights.")

    write_text(out_dir / "EVIDENCE_GAPS.md", "\n".join(lines))


# ============================
# MAIN
# ============================

def main() -> None:
    root = repo_root()
    cust_root = customers_root(root)
    out_root = synthesis_root(root)

    parser = argparse.ArgumentParser(description="Build cross-customer synthesis from customer rollups.")
    parser.add_argument("--only", type=str, default="", help="Only include customers whose folder contains this substring.")
    parser.add_argument("--limit", type=int, default=0, help="Process at most N customers (0 = no limit).")
    parser.add_argument("--dry-run", action="store_true", help="Print summary only, do not write output files.")
    parser.add_argument("--exclude-internal", action="store_true", help="Exclude customer_id == 'internal' and 'unknown'.")
    args = parser.parse_args()

    if not cust_root.exists():
        raise SystemExit(f"ERROR: Customers folder not found: {cust_root}")

    customer_dirs = sorted([p for p in cust_root.iterdir() if p.is_dir() and p.name != "_registry"])
    if args.only:
        customer_dirs = [p for p in customer_dirs if args.only.lower() in p.name.lower()]
    if args.exclude_internal:
        customer_dirs = [p for p in customer_dirs if p.name not in ("internal", "unknown")]
    if args.limit:
        customer_dirs = customer_dirs[:args.limit]

    if not customer_dirs:
        print("No customers matched.")
        return

    jtbd_store: Dict[str, SynthItem] = {}
    ins_store: Dict[str, SynthItem] = {}

    for cdir in customer_dirs:
        customer_id = cdir.name

        jtbd_path = cdir / "JTBD.md"
        ins_path = cdir / "INSIGHTS.md"
        calls_path = cdir / "CALLS.md"

        # Call types (used later for analysis; optional)
        call_types: List[str] = []
        if calls_path.exists():
            links = parse_calls_md(read_text(calls_path))
            call_types = [l.call_type for l in links if l.call_type and l.call_type.lower() != "unknown"]

        if jtbd_path.exists():
            jtbd_items = parse_rollup(read_text(jtbd_path), "jtbd")
            for it in jtbd_items:
                add_to_synth(jtbd_store, it, customer_id, call_types)

        if ins_path.exists():
            ins_items = parse_rollup(read_text(ins_path), "insight")
            for it in ins_items:
                add_to_synth(ins_store, it, customer_id, call_types)

    if args.dry_run:
        print(f"[DRY RUN] Customers included: {len(customer_dirs)}")
        print(f"JTBD canonical: {len(jtbd_store)}")
        print(f"Insights canonical: {len(ins_store)}")
        calltype_totals = aggregate_calltype_totals([jtbd_store, ins_store])
        if calltype_totals:
            print("[DRY RUN] Call type coverage (customers mentioning type):")
            for ct, count in sorted(calltype_totals.items(), key=lambda kv: kv[1], reverse=True)[:5]:
                print(f"  - {ct}: {count}")
        else:
            print("[DRY RUN] Call type coverage: none detected")
        return

    out_root.mkdir(parents=True, exist_ok=True)

    write_canonical_md(out_root, "JTBD_CANONICAL.md", "JTBD Canonical", jtbd_store)
    write_canonical_md(out_root, "INSIGHTS_CANONICAL.md", "Insights Canonical", ins_store)
    write_themes_md(out_root, jtbd_store, ins_store)
    write_contradictions_md(out_root, jtbd_store, ins_store)
    write_evidence_gaps_md(out_root, ins_store)

    # Small index file for convenience
    write_text(out_root / "README.md", "\n".join([
        "# Synthesis",
        "",
        "- `JTBD_CANONICAL.md` — ranked cross-customer JTBD",
        "- `INSIGHTS_CANONICAL.md` — ranked cross-customer insights",
        "- `THEMES.md` — heuristic theme buckets",
        "- `CONTRADICTIONS.md` — heuristic keyword tensions",
        "- `EVIDENCE_GAPS.md` — recurring items with weak captured quotes",
        "",
        "Tip: re-run after updating customer metadata and regenerating customer rollups.",
    ]))

    print(f"Wrote synthesis to: {out_root.relative_to(root)}")
    print("Done.")


if __name__ == "__main__":
    main()
