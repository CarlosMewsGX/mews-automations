#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from azure_openai_client import AzureOpenAIClient, load_azure_openai_config
from user_context import USER_CONTEXT_FILENAME, format_user_context_for_prompt, load_user_context


# ============================
# CONFIG
# ============================

PRDS_ROOT = Path("03_prds")
TEMPLATES_DIR = PRDS_ROOT / "_templates"  # not required here but kept for consistency

# Accept both naming conventions (we’ll use whichever exists)
INPUT_ALIASES = ["01_scope.md", "01_inputs.md"]

PRD_FILE = "00_prd.md"
KEY_JTBD_FILE = "04_key_jtbd.md"
KEY_INSIGHTS_FILE = "05_key_insights.md"

OUT_FILE = "06_hypotheses.md"
RUNLOG = "ai_hypotheses_run.json"
RAW = "ai_hypotheses_raw_response.txt"


# ============================
# UTIL
# ============================

def repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def read_text(p: Path) -> str:
    return p.read_text(encoding="utf-8", errors="replace")


def write_text(p: Path, text: str) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text.rstrip() + "\n", encoding="utf-8")


def now_utc_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def safe_slug(s: str) -> str:
    s = s.strip().lower()
    s = s.replace("&", " and ")
    s = re.sub(r"[^a-z0-9]+", "-", s)
    s = re.sub(r"-{2,}", "-", s).strip("-")
    return s or "unknown"


def rel(base: Path, p: Path) -> str:
    return str(p.relative_to(base)).replace("\\", "/")


def find_inputs_file(prd_dir: Path) -> Optional[Path]:
    for name in INPUT_ALIASES:
        p = prd_dir / name
        if p.exists():
            return p
    return None


# ============================
# PROMPT
# ============================

def build_prompt(
    prd_md: str,
    scope_md: str,
    key_jtbd_md: str,
    key_insights_md: str,
    user_context: str,
) -> str:
    context_block = format_user_context_for_prompt(user_context)

    return f"""
You are a senior product discovery assistant.

Your task: produce a set of TESTABLE, FALSIFIABLE product hypotheses for a PRD.

CRITICAL RULES:
- Use ONLY the provided PRD, scope, key JTBD, and key insights.
- Do NOT invent customer facts or metrics not present.
- If something is unknown, mark it as "TBD".
- Output must be valid Markdown.
- Do NOT wrap output in triple backticks.
- Do NOT reference raw calls that aren’t in scope.

QUALITY BAR:
Each hypothesis MUST include:
- A clear intervention (what we change/build)
- An expected measurable outcome (what changes)
- A test method (how we’d validate)
- Risks / confounders
- Explicit grounding via references to Key JTBD and Key Insights items

OUTPUT FORMAT (must follow exactly)

# Hypotheses

## HYP-001: <short hypothesis title>
- Hypothesis: <If we do X, then Y will improve because Z.>
- Evidence:
  - JTBD: <reference one or more items by their title or index number from Key JTBD>
  - Insights: <reference one or more items by their title or index number from Key Insights>
- Test:
  - Method: <A/B, cohort rollout, usability test, concierge, shadow-mode, etc.>
  - Success metric(s): <must be plausible and not invented; use "TBD" if not present>
  - Guardrail metric(s): <TBD ok>
  - Time window: <e.g., 2 weeks, 1 month, TBD>
- Risks / Confounders:
  - <bullets>
- Notes:
  - Dependencies: <bullets or TBD>
  - Assumptions: <bullets or TBD>

Generate 6–10 hypotheses. Prefer fewer if evidence is weak.
If evidence is weak, you must say so in the hypothesis Notes.

INPUTS:

PRD (00_prd.md):
{prd_md}

SCOPE (01_scope.md / 01_inputs.md):
{scope_md}

KEY JTBD (04_key_jtbd.md):
{key_jtbd_md}

KEY INSIGHTS (05_key_insights.md):
{key_insights_md}
{context_block}
""".strip()


# ============================
# VALIDATION
# ============================

HYP_RE = re.compile(r"^##\s*HYP-\d{3}:", re.MULTILINE)


def validate_output(md: str) -> None:
    if len(md.strip()) < 400:
        raise RuntimeError("Hypotheses output returned too little content.")
    if md.lstrip().startswith("```"):
        raise RuntimeError("Output was wrapped in backticks; refusing to write.")
    if not md.strip().startswith("# Hypotheses"):
        raise RuntimeError("Output must start with '# Hypotheses'.")
    if not HYP_RE.search(md):
        raise RuntimeError("Output missing hypothesis headers like '## HYP-001:'.")


# ============================
# GENERATE ONE PRD
# ============================

def generate_one(prd_slug: str, temperature: float, force: bool, dry_run: bool) -> None:
    root = repo_root()
    user_context = load_user_context(root)
    prd_dir = root / PRDS_ROOT / prd_slug

    if not prd_dir.exists():
        raise SystemExit(f"ERROR: PRD folder not found: {prd_dir}")

    scope_path = find_inputs_file(prd_dir)
    if not scope_path:
        raise SystemExit(
            "ERROR: Missing PRD scope/inputs file.\n"
            f"Looked for: {', '.join(INPUT_ALIASES)}\n"
            f"Expected one of those in: {prd_dir}"
        )

    prd_path = prd_dir / PRD_FILE
    jtbd_path = prd_dir / KEY_JTBD_FILE
    ins_path = prd_dir / KEY_INSIGHTS_FILE

    missing = [p.name for p in (prd_path, jtbd_path, ins_path) if not p.exists()]
    if missing:
        raise SystemExit(
            "ERROR: Missing required PRD inputs. Ensure you ran generate_prd.py and generate_prd_md.py.\n"
            f"Missing: {', '.join(missing)}"
        )

    out_path = prd_dir / OUT_FILE
    if out_path.exists() and not force:
        print(f"[SKIP] {rel(root, out_path)} exists. Use --force to overwrite.")
        return

    prd_md = read_text(prd_path)
    scope_md = read_text(scope_path)
    key_jtbd_md = read_text(jtbd_path)
    key_insights_md = read_text(ins_path)

    prompt = build_prompt(prd_md, scope_md, key_jtbd_md, key_insights_md, user_context)

    if dry_run:
        print(f"[DRY RUN] Would generate {rel(root, out_path)} using Azure OpenAI")
        return

    config = load_azure_openai_config(root)
    client = AzureOpenAIClient(config)
    raw = client.generate(prompt, temperature)

    write_text(prd_dir / RAW, raw)
    validate_output(raw)
    write_text(out_path, raw)

    write_text(prd_dir / RUNLOG, json.dumps({
        "model": client.config.deployment,
        "api_version": client.config.api_version,
        "temperature": temperature,
        "ran_at": now_utc_iso(),
        "prompt_chars": len(prompt),
        "response_chars": len(raw),
        "user_context_chars": len(user_context),
        "user_context_path": str(root / USER_CONTEXT_FILENAME) if user_context else None,
        "scope_file_used": str(scope_path),
        "inputs": {
            "prd": str(prd_path),
            "key_jtbd": str(jtbd_path),
            "key_insights": str(ins_path),
        },
        "output": str(out_path),
    }, indent=2))

    print(f"[WRITE] {rel(root, out_path)}")
    print(f"[LOG]   {rel(root, prd_dir / RUNLOG)}")
    print(f"[RAW]   {rel(root, prd_dir / RAW)}")


# ============================
# ENTRY POINT
# ============================

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Generate 06_hypotheses.md using Azure OpenAI from PRD-scoped evidence (no raw calls)."
    )
    parser.add_argument("--prd", type=str, default="", help="PRD slug under 03_prds/<prd-slug> to generate.")
    parser.add_argument("--all", action="store_true", help="Generate for all PRDs that have required files.")
    parser.add_argument("--temperature", type=float, default=0.2)
    parser.add_argument("--force", action="store_true", help="Overwrite 06_hypotheses.md if it exists.")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    root = repo_root()
    prds_root = root / PRDS_ROOT
    if not prds_root.exists():
        raise SystemExit(f"ERROR: PRD root not found: {prds_root}")

    if args.all and args.prd:
        raise SystemExit("ERROR: Use either --prd <slug> OR --all, not both.")

    if args.all:
        for p in sorted(prds_root.iterdir()):
            if not p.is_dir():
                continue
            if p.name.startswith("_"):
                continue

            # required inputs must exist
            if not find_inputs_file(p):
                continue
            if not (p / PRD_FILE).exists():
                continue
            if not (p / KEY_JTBD_FILE).exists():
                continue
            if not (p / KEY_INSIGHTS_FILE).exists():
                continue

            print("\n" + "=" * 80)
            print(f"PRD: {p.name}")
            print("=" * 80)
            generate_one(p.name, args.temperature, args.force, args.dry_run)

        print("\nDone.")
        return

    if not args.prd:
        raise SystemExit("ERROR: Missing --prd <prd-slug> (or use --all).")

    slug = safe_slug(args.prd)
    generate_one(slug, args.temperature, args.force, args.dry_run)
    print("\nDone.")


if __name__ == "__main__":
    main()
