#Helper for loading optional user context into AI prompts.
from __future__ import annotations

from pathlib import Path

USER_CONTEXT_FILENAME = "USER_CONTEXT.md"


def load_user_context(root: Path) -> str:
    """
    Load optional user-provided context text.

    - Skips blank lines and comment lines ("# ..." or HTML comments).
    - Returns an empty string if the file is missing or contains no usable text.
    """

    path = root / USER_CONTEXT_FILENAME
    if not path.exists():
        return ""

    raw = path.read_text(encoding="utf-8", errors="replace")
    lines = []
    in_html_comment = False

    for line in raw.splitlines():
        stripped = line.strip()

        if not stripped:
            continue
        if stripped.startswith("<!--"):
            if stripped.endswith("-->"):
                continue
            in_html_comment = True
            continue
        if in_html_comment:
            if stripped.endswith("-->"):
                in_html_comment = False
            continue
        if stripped.startswith("#"):
            continue

        lines.append(line.rstrip())

    return "\n".join(lines).strip()


def format_user_context_for_prompt(user_context: str) -> str:
    """Return a prompt-ready block when context exists; otherwise empty string."""

    if not user_context:
        return ""

    return (
        "\n\nUSER CONTEXT (background to tailor tone, names, and priorities — "
        "do not override the provided inputs):\n"
        f"{user_context}\n"
    )
