#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from azure_openai_client import AzureOpenAIClient, load_azure_openai_config
from user_context import format_user_context_for_prompt, load_user_context

# ============================
# CONFIG
# ============================

CHECK_EMOJI = " ✅"
MAX_OUTPUT_TOKENS = 12288

# ============================
# PATHS
# ============================


def repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


@dataclass
class CallPaths:
    folder: Path
    analyzed_flag: Path
    metadata: Path
    transcript: Path
    summary: Path
    jtbd: Path
    insights: Path
    evidence: Path
    followups: Path
    runlog: Path
    raw_response: Path


def get_call_paths(folder: Path) -> CallPaths:
    return CallPaths(
        folder=folder,
        analyzed_flag=folder / "ANALYZED.flag",
        metadata=folder / "00_metadata.md",
        transcript=folder / "01_transcript.md",
        summary=folder / "02_ai_summary.md",
        jtbd=folder / "03_ai_jtbd.md",
        insights=folder / "04_ai_insights.md",
        evidence=folder / "05_evidence_clips.md",
        followups=folder / "06_followups.md",
        runlog=folder / "ai_run.json",
        raw_response=folder / "ai_raw_response.txt",
    )


# ============================
# HELPERS
# ============================


def read_text(p: Path) -> str:
    return p.read_text(encoding="utf-8", errors="replace")


def write_text(p: Path, text: str) -> None:
    p.write_text(text.rstrip() + "\n", encoding="utf-8")


def ensure_emoji(folder: Path) -> Path:
    """
    Adds the ✅ suffix if not present and returns the new Path.
    Performed only after successful analysis to avoid path breakage mid-run.
    """
    if folder.name.endswith(CHECK_EMOJI):
        return folder
    new_path = folder.parent / f"{folder.name}{CHECK_EMOJI}"
    folder.rename(new_path)
    return new_path


def mark_analyzed(folder: Path) -> None:
    (folder / "ANALYZED.flag").write_text(
        datetime.now(timezone.utc).isoformat() + "\n", encoding="utf-8"
    )


def is_already_analyzed(folder: Path) -> bool:
    return (folder / "ANALYZED.flag").exists()


def log_progress(i: int, total: int, status: str, name: str, extra: str = "") -> None:
    pct = (i / total * 100) if total else 100.0
    suffix = f" — {extra}" if extra else ""
    print(f"[{i}/{total} | {pct:5.1f}%] {status:<10} {name}{suffix}", flush=True)


# ============================
# PROMPTS
# ============================


def build_metadata_prompt(existing_metadata: str, transcript: str, user_context: str) -> str:
    context_block = format_user_context_for_prompt(user_context)

    return f"""
You are helping maintain a call metadata file.

You must infer metadata ONLY from the transcript and existing metadata.
If not clear, return "unknown" / "UNKNOWN".

Return VALID JSON ONLY (no ```).

OUTPUT JSON SCHEMA:
{{
  "customer_name": "UNKNOWN or human-readable customer/org name",
  "customer_id": "unknown or a lowercase slug like westcord, bastion-hotels",
  "call_type": "UNKNOWN or one of: discovery, feedback, support, internal, demo"
}}

RULES:
- Do NOT guess company names if not mentioned explicitly.
- customer_id must be a slug (lowercase, hyphen-separated), or "unknown".
- If the call is internal (no external customer), set call_type="internal" and customer_id="internal", customer_name="Internal / Mews".
{context_block}

EXISTING METADATA:
{existing_metadata}

TRANSCRIPT:
{transcript}
""".strip()


def build_analysis_prompt(metadata: str, transcript: str, user_context: str) -> str:
    context_block = format_user_context_for_prompt(user_context)

    return f"""
You are an expert Product Researcher supporting a Product Management team.

Analyze ONE customer call.

CRITICAL RULES:
- Use ONLY the transcript and metadata provided.
- Do NOT invent facts.
- Every statement must be grounded in the call.
- If a section is not mentioned, write exactly: "Not mentioned in this call."
- Output MUST be valid JSON.
- Do NOT wrap output in ```.

IMPORTANT OUTPUT REQUIREMENT:
- You must output FULL MARKDOWN in jtbd_lines and insights_lines using the EXACT templates below.
- Do not output simple bullet lists for JTBD/Insights. If you do, your output will be rejected.
{context_block}

OUTPUT JSON SCHEMA:
{{
  "summary_sections": {{
    "Context": ["..."],
    "Key Problems": ["..."],
    "Workflows & Behaviours": ["..."],
    "Metrics & Definitions Mentioned": ["..."],
    "Constraints & Trade-offs": ["..."],
    "Desired Outcomes": ["..."],
    "Risks / Red Flags": ["..."],
    "Recommended Follow-ups": ["..."]
  }},
  "jtbd_lines": ["markdown lines"],
  "insights_lines": ["markdown lines"],
  "evidence_clips_lines": ["markdown lines"],
  "followups_lines": ["markdown lines"]
}}

TEMPLATE: JTBD (must follow exactly)
# Jobs To Be Done (JTBD)

## JTBD-001: <short JTBD title>
- When: <situation>
- I want to: <job>
- So I can: <benefit/outcome>
- Evidence:
  - Timestamp: <hh:mm:ss or Not mentioned in this call.>
  - Quote: <verbatim or Not mentioned in this call.>
- Confidence: <0.00 to 1.00>
- Applies to: <departments/personas>
- Notes: <assumptions/edge cases or Not mentioned in this call.>

(Repeat JTBD-002, JTBD-003... up to max 8)

TEMPLATE: INSIGHTS (must follow exactly)
# Insights

## INS-001: <short insight title>
- Insight: <one sentence insight>
- Evidence:
  - Timestamp: <hh:mm:ss or Not mentioned in this call.>
  - Quote: <verbatim or Not mentioned in this call.>
- Confidence: <0.00 to 1.00>
- Theme: <one of: Finance & Invoicing | Revenue & Pricing | Operations | Reporting & Self-serve | Data Quality & Definitions | Integrations & Data Sources | Uncategorized>
- Applies to: <departments/personas>
- Implication: <what this suggests for product/discovery or Not mentioned in this call.>

(Repeat INS-002... up to max 10)

TEMPLATE: Evidence clips
# Evidence Clips
- Clip 1: <timestamp> — <quote>
- Clip 2: <timestamp> — <quote>
(up to 10 clips; if none, write: - Not mentioned in this call.)

TEMPLATE: Follow-ups
# Follow-ups
- Question 1: ...
- Question 2: ...
(up to 10; if none, write: - Not mentioned in this call.)

METADATA:
{metadata}

TRANSCRIPT:
{transcript}
""".strip()


# ============================
# JSON PARSING (HARDENED)
# ============================


def parse_json(raw: str) -> Dict:
    raw = raw.strip()

    fence = re.match(
        r"^\s*```(?:json)?\s*(.*?)\s*```\s*$",
        raw,
        re.DOTALL | re.IGNORECASE,
    )
    if fence:
        raw = fence.group(1).strip()

    raw = re.sub(r"^\s*json\s*\n", "", raw, flags=re.IGNORECASE)

    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        pass

    start, end = raw.find("{"), raw.rfind("}")
    if start == -1 or end == -1 or end <= start:
        raise json.JSONDecodeError("No JSON object found", raw, 0)

    candidate = raw[start : end + 1]

    # Remove trailing commas before } or ]
    candidate = re.sub(r",\s*([}\]])", r"\1", candidate)

    return json.loads(candidate)


# ============================
# VALIDATION
# ============================

JTBD_MIN_RE = re.compile(r"^##\s*JTBD-\d{3}:", re.MULTILINE)
INS_MIN_RE = re.compile(r"^##\s*INS-\d{3}:", re.MULTILINE)


def validate_structured_markdown(jtbd_md: str, ins_md: str) -> Optional[str]:
    if not jtbd_md.strip().startswith("# Jobs To Be Done (JTBD)"):
        return "JTBD markdown must start with '# Jobs To Be Done (JTBD)'"
    if not ins_md.strip().startswith("# Insights"):
        return "Insights markdown must start with '# Insights'"
    if not JTBD_MIN_RE.search(jtbd_md):
        return "JTBD markdown missing required headers like '## JTBD-001:'"
    if not INS_MIN_RE.search(ins_md):
        return "Insights markdown missing required headers like '## INS-001:'"
    return None


# ============================
# ANALYSIS
# ============================


def analyze_folder(
    client: AzureOpenAIClient,
    folder: Path,
    force: bool,
    dry_run: bool,
    temperature: float,
    user_context: str,
) -> bool:
    if not folder.exists():
        raise RuntimeError("Folder does not exist (stale path)")

    if not force and is_already_analyzed(folder):
        return False

    cp = get_call_paths(folder)

    if not cp.transcript.exists():
        raise RuntimeError("Missing 01_transcript.md")

    transcript_text = read_text(cp.transcript)
    metadata_text = read_text(cp.metadata) if cp.metadata.exists() else "# Metadata\n"
    prompt = build_analysis_prompt(metadata_text, transcript_text, user_context)

    if dry_run:
        print(f"[DRY RUN] Would analyze {folder.name}")
        return True

    raw = client.generate(
        prompt,
        temperature,
        max_output_tokens=MAX_OUTPUT_TOKENS,
        response_format={"type": "json_object"},
    )
    write_text(cp.raw_response, raw)

    try:
        out = parse_json(raw)
    except json.JSONDecodeError as e:
        ctx = 250
        snippet = raw[max(e.pos - ctx, 0) : min(e.pos + ctx, len(raw))]
        write_text(
            cp.runlog,
            json.dumps(
                {
                    "error": "JSON decode error from model output",
                    "details": str(e),
                    "line": e.lineno,
                    "col": e.colno,
                    "pos": e.pos,
                    "snippet_around_error": snippet,
                    "model": client.config.deployment,
                    "api_version": client.config.api_version,
                    "temperature": temperature,
                    "ran_at": datetime.now(timezone.utc).isoformat(),
                    "prompt_chars": len(prompt),
                    "response_chars": len(raw),
                    "raw_response_path": str(cp.raw_response),
                },
                indent=2,
            ),
        )
        raise

    def write_error_and_raise(msg: str) -> None:
        write_text(
            cp.runlog,
            json.dumps(
                {
                    "error": msg,
                    "model": client.config.deployment,
                    "api_version": client.config.api_version,
                    "temperature": temperature,
                    "ran_at": datetime.now(timezone.utc).isoformat(),
                    "prompt_chars": len(prompt),
                    "response_chars": len(raw),
                    "user_context_chars": len(user_context),
                    "raw_response_path": str(cp.raw_response),
                },
                indent=2,
            ),
        )
        raise RuntimeError(msg)

    # Validate and normalize structure
    if not isinstance(out, dict):
        write_error_and_raise("AI response is not a JSON object")

    expected_fields = [
        "summary_sections",
        "jtbd_lines",
        "insights_lines",
        "evidence_clips_lines",
        "followups_lines",
    ]
    for field in expected_fields:
        if field not in out:
            write_error_and_raise(f"Missing field in AI response: {field}")

    if not isinstance(out["summary_sections"], dict):
        write_error_and_raise("summary_sections must be an object of sections -> list[str]")

    summary_expected_sections = [
        "Context",
        "Key Problems",
        "Workflows & Behaviours",
        "Metrics & Definitions Mentioned",
        "Constraints & Trade-offs",
        "Desired Outcomes",
        "Risks / Red Flags",
        "Recommended Follow-ups",
    ]

    normalized_summary: Dict[str, List[str]] = {}
    for section in summary_expected_sections:
        lines = out["summary_sections"].get(section, None)
        if lines is None:
            write_error_and_raise(f"summary_sections missing '{section}'")
        if not isinstance(lines, list) or not all(isinstance(l, str) for l in lines):
            write_error_and_raise(f"summary_sections['{section}'] must be a list of strings")
        normalized_summary[section] = lines or ["Not mentioned in this call."]

    def ensure_list_of_str(key: str) -> List[str]:
        value = out.get(key)
        if not isinstance(value, list) or not all(isinstance(v, str) for v in value):
            write_error_and_raise(f"{key} must be a list of strings")
        return value

    jtbd_lines = ensure_list_of_str("jtbd_lines")
    insights_lines = ensure_list_of_str("insights_lines")
    evidence_lines = ensure_list_of_str("evidence_clips_lines")
    followups_lines = ensure_list_of_str("followups_lines")

    if not jtbd_lines:
        jtbd_lines = [
            "# Jobs To Be Done (JTBD)",
            "",
            "## JTBD-001: Not mentioned in this call.",
            "- When: Not mentioned in this call.",
            "- I want to: Not mentioned in this call.",
            "- So I can: Not mentioned in this call.",
            "- Evidence:",
            "  - Timestamp: Not mentioned in this call.",
            "  - Quote: Not mentioned in this call.",
            "- Confidence: 0.00",
            "- Applies to: Not mentioned in this call.",
            "- Notes: Not mentioned in this call.",
            "",
        ]

    if not insights_lines:
        insights_lines = [
            "# Insights",
            "",
            "## INS-001: Not mentioned in this call.",
            "- Insight: Not mentioned in this call.",
            "- Evidence:",
            "  - Timestamp: Not mentioned in this call.",
            "  - Quote: Not mentioned in this call.",
            "- Confidence: 0.00",
            "- Theme: Uncategorized",
            "- Applies to: Not mentioned in this call.",
            "- Implication: Not mentioned in this call.",
            "",
        ]

    if not evidence_lines:
        evidence_lines = ["# Evidence Clips", "- Not mentioned in this call.", ""]

    if not followups_lines:
        followups_lines = ["# Follow-ups", "- Not mentioned in this call.", ""]

    # Summary
    md_summary = "# AI Summary\n\n"
    for section, lines in normalized_summary.items():
        md_summary += f"## {section}\n"
        for line in lines:
            md_summary += f"- {line}\n"
        md_summary += "\n"

    jtbd_md = "\n".join(jtbd_lines).strip() + "\n"
    ins_md = "\n".join(insights_lines).strip() + "\n"
    evidence_md = "\n".join(evidence_lines).strip() + "\n"
    followups_md = "\n".join(followups_lines).strip() + "\n"

    validation_error = validate_structured_markdown(jtbd_md, ins_md)
    if validation_error:
        write_text(
            cp.runlog,
            json.dumps(
                {
                    "error": f"Output validation failed: {validation_error}",
                    "model": client.config.deployment,
                    "api_version": client.config.api_version,
                    "temperature": temperature,
                    "ran_at": datetime.now(timezone.utc).isoformat(),
                    "prompt_chars": len(prompt),
                    "response_chars": len(raw),
                },
                indent=2,
            ),
        )
        raise RuntimeError(validation_error)

    write_text(cp.summary, md_summary)
    write_text(cp.jtbd, jtbd_md)
    write_text(cp.insights, ins_md)
    write_text(cp.evidence, evidence_md)
    write_text(cp.followups, followups_md)

    # IMPORTANT: Mark analyzed + emoji only after all writes succeed
    final_folder = ensure_emoji(folder)
    mark_analyzed(final_folder)

    # Write runlog into the final folder path (emoji may have changed folder name)
    cp_final = get_call_paths(final_folder)
    write_text(
        cp_final.runlog,
        json.dumps(
            {
                "model": client.config.deployment,
                "api_version": client.config.api_version,
                "temperature": temperature,
                "ran_at": datetime.now(timezone.utc).isoformat(),
                "prompt_chars": len(prompt),
                "response_chars": len(raw),
                "user_context_chars": len(user_context),
                "folder_emoji_applied": (final_folder != folder),
            },
            indent=2,
        ),
    )

    return True


def process_folder(
    idx: int,
    total: int,
    folder: Path,
    client: AzureOpenAIClient,
    force: bool,
    dry_run: bool,
    temperature: float,
    user_context: str,
) -> str:
    log_progress(idx, total, "PROCESSING", folder.name)
    try:
        did = analyze_folder(client, folder, force, dry_run, temperature, user_context)
        if did:
            log_progress(idx, total, "DONE", folder.name)
            return "analyzed"
        log_progress(idx, total, "SKIPPED", folder.name)
        return "skipped"
    except Exception as e:
        log_progress(idx, total, "ERROR", folder.name, extra=str(e)[:180])
        return "error"


# ============================
# ENTRY POINT
# ============================


def main() -> None:
    root = repo_root()
    processed = root / "01_library" / "calls" / "processed"
    user_context = load_user_context(root)

    parser = argparse.ArgumentParser()
    parser.add_argument("--temperature", type=float, default=0.2)
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--limit", type=int, default=0)
    parser.add_argument("--only", type=str, default="")
    args = parser.parse_args()

    config = load_azure_openai_config(root)
    client = AzureOpenAIClient(config)

    folders = sorted(p for p in processed.iterdir() if p.is_dir())
    if args.only:
        folders = [f for f in folders if args.only.lower() in f.name.lower()]

    # Worklist uses ANALYZED.flag, not emoji
    worklist: List[Path] = []
    skipped = 0
    for f in folders:
        if (not args.force) and is_already_analyzed(f):
            skipped += 1
            continue
        worklist.append(f)

    total = len(worklist)
    analyzed = 0
    errors = 0

    if total == 0:
        print(
            "Nothing to do. skipped={skipped} (ANALYZED.flag exists). model={model}".format(
                skipped=skipped,
                model=client.config.deployment,
            )
        )
        return

    indexed_worklist = list(enumerate(worklist, start=1))
    for start in range(0, total, 5):
        batch = indexed_worklist[start : start + 5]
        with ThreadPoolExecutor(max_workers=len(batch)) as executor:
            futures = [
                executor.submit(
                    process_folder,
                    idx,
                    total,
                    folder,
                    client,
                    args.force,
                    args.dry_run,
                    args.temperature,
                    user_context,
                )
                for idx, folder in batch
            ]

            for future in as_completed(futures):
                status = future.result()
                if status == "analyzed":
                    analyzed += 1
                elif status == "skipped":
                    skipped += 1
                else:
                    errors += 1

                if args.limit and analyzed >= args.limit:
                    break

        if args.limit and analyzed >= args.limit:
            break

    print(
        "Done. analyzed={analyzed}, skipped={skipped}, errors={errors}, model={model}".format(
            analyzed=analyzed,
            skipped=skipped,
            errors=errors,
            model=client.config.deployment,
        )
    )


if __name__ == "__main__":
    main()
