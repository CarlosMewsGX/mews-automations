#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import re
import shutil
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple


# ============================
# CONFIG / PATHS
# ============================

PRDS_ROOT = Path("03_prds")
TEMPLATES_DIR = PRDS_ROOT / "_templates"
PRD_INDEX_PATH = PRDS_ROOT / "PRD_INDEX.md"

TEMPLATE_MAP = {
    "PRD_TEMPLATE.md": "00_prd.md",
    "RESEARCH_GUIDE_TEMPLATE.md": "02_research_guide.md",
    "RESEARCH_SUMMARY_TEMPLATE.md": "03_research_summary.md",  # will be overwritten by generator
    # CALL_LINK_TEMPLATE.md intentionally not copied by default (not needed for this workflow)
}

SCOPE_FILE = "01_scope.md"

# Expected call folder files (produced by analyze_calls.py)
CALL_SUMMARY = "02_ai_summary.md"
CALL_JTBD = "03_ai_jtbd.md"
CALL_INSIGHTS = "04_ai_insights.md"
CALL_EVIDENCE = "05_evidence_clips.md"


# ============================
# UTIL
# ============================

def repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def read_text(p: Path) -> str:
    return p.read_text(encoding="utf-8", errors="replace")


def write_text(p: Path, text: str) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text.rstrip() + "\n", encoding="utf-8")


def safe_slug(s: str) -> str:
    s = s.strip().lower()
    s = s.replace("&", " and ")
    s = re.sub(r"[^a-z0-9]+", "-", s)
    s = re.sub(r"-{2,}", "-", s).strip("-")
    return s or "unknown"


def normalize_key(s: str) -> str:
    s = s.strip().lower()
    s = re.sub(r"\s+", " ", s)
    s = re.sub(r"[^\w\s-]", "", s)
    return s


def relpath_md(from_dir: Path, to_path: Path) -> str:
    return os.path.relpath(to_path, start=from_dir).replace("\\", "/")


def now_utc_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def now_utc_date() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")


# ============================
# SCOPE PARSING
# ============================

SCOPE_CALLS_HEADER_RE = re.compile(r"^\s*##\s*Calls\b.*$", re.IGNORECASE | re.MULTILINE)
BULLET_RE = re.compile(r"^\s*-\s+(.+?)\s*$", re.MULTILINE)


def parse_scope_calls(scope_md: str) -> List[str]:
    """
    Extract bullet lines that appear *after* the first "## Calls" header.
    Everything else in the scope file is ignored.
    """
    m = SCOPE_CALLS_HEADER_RE.search(scope_md)
    if not m:
        raise ValueError("Scope file must contain a '## Calls' section with bullet list of call folder paths.")

    tail = scope_md[m.end():]
    # Stop at next H2 header if present
    next_h2 = re.search(r"^\s*##\s+", tail, flags=re.MULTILINE)
    if next_h2:
        tail = tail[:next_h2.start()]

    calls = [x.strip() for x in (b.group(1) for b in BULLET_RE.finditer(tail)) if x and x.strip()]
    # remove trailing comments
    calls = [c.split(" #", 1)[0].strip() for c in calls]
    calls = [c for c in calls if c]
    return calls


# ============================
# JTBD / INSIGHTS EXTRACTION
# ============================

JTBD_HEADER_RE = re.compile(r"^#{2,3}\s*JTBD-\d{3}:\s*(.+?)\s*$", re.MULTILINE)
INS_HEADER_RE = re.compile(r"^#{2,3}\s*INS-\d{3}:\s*(.+?)\s*$", re.MULTILINE)

# Fallback: bullet-only items (legacy)
BULLET_LINE_RE = re.compile(r"^\s*-\s+(.*\S)\s*$", re.MULTILINE)

EVIDENCE_TS_RE = re.compile(r"^\s*-\s*Timestamp:\s*(.*)\s*$", re.MULTILINE | re.IGNORECASE)
EVIDENCE_QUOTE_RE = re.compile(r"^\s*-\s*Quote:\s*(.*)\s*$", re.MULTILINE | re.IGNORECASE)


@dataclass
class Occurrence:
    call_folder: Path
    call_label: str
    timestamp: str
    quote: str


@dataclass
class CanonicalItem:
    title: str
    key: str
    occurrences: List[Occurrence]


def split_structured_sections(md: str, header_re: re.Pattern) -> List[Tuple[str, str]]:
    """
    Returns [(title, section_text)] for each header match.
    """
    matches = list(header_re.finditer(md))
    out: List[Tuple[str, str]] = []
    for i, m in enumerate(matches):
        start = m.start()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(md)
        title = m.group(1).strip()
        section = md[start:end].strip()
        out.append((title, section))
    return out


def extract_best_evidence(section_text: str) -> Tuple[str, str]:
    ts = ""
    q = ""
    tm = EVIDENCE_TS_RE.search(section_text)
    if tm:
        ts = tm.group(1).strip()
    qm = EVIDENCE_QUOTE_RE.search(section_text)
    if qm:
        q = qm.group(1).strip()
    return ts, q


def extract_items(md: str, kind: str) -> List[Tuple[str, str, str, str]]:
    """
    Returns list of (title, key, timestamp, quote)
    """
    md = (md or "").strip()
    items: List[Tuple[str, str, str, str]] = []

    if kind == "jtbd":
        sections = split_structured_sections(md, JTBD_HEADER_RE)
    else:
        sections = split_structured_sections(md, INS_HEADER_RE)

    if sections:
        for title, section in sections:
            ts, q = extract_best_evidence(section)
            items.append((title, normalize_key(title), ts, q))
        return items

    # Fallback bullet-only legacy
    bullets = [m.group(1).strip() for m in BULLET_LINE_RE.finditer(md)]
    bullets = [b for b in bullets if b and "not mentioned in this call" not in b.lower()]
    for b in bullets:
        words = re.sub(r"\*\*", "", b)
        words = re.sub(r"[^\w\s-]", "", words)
        title = " ".join(words.split()[:12]).strip() or (f"{kind.upper()} item")
        items.append((title, normalize_key(title), "", ""))
    return items


def add_occurrence(
    store: Dict[str, CanonicalItem],
    title: str,
    key: str,
    call_folder: Path,
    call_label: str,
    timestamp: str,
    quote: str,
) -> None:
    occ = Occurrence(call_folder=call_folder, call_label=call_label, timestamp=timestamp or "", quote=quote or "")
    if key not in store:
        store[key] = CanonicalItem(title=title, key=key, occurrences=[occ])
    else:
        store[key].occurrences.append(occ)


def sort_canonical(items: List[CanonicalItem]) -> List[CanonicalItem]:
    # primary: frequency desc; secondary: title asc
    return sorted(items, key=lambda x: (-len(x.occurrences), x.title.lower()))


# ============================
# TEMPLATE COPYING
# ============================

def ensure_templates(prd_dir: Path, overwrite: bool = False) -> List[str]:
    """
    Copy template files into PRD folder to save time.
    Returns list of actions performed.
    """
    actions: List[str] = []
    if not TEMPLATES_DIR.exists():
        raise FileNotFoundError(f"Templates dir not found: {TEMPLATES_DIR}")

    for src_name, dst_name in TEMPLATE_MAP.items():
        src = TEMPLATES_DIR / src_name
        dst = prd_dir / dst_name
        if not src.exists():
            actions.append(f"SKIP missing template: {src_name}")
            continue
        if dst.exists() and not overwrite:
            continue
        shutil.copyfile(src, dst)
        actions.append(f"COPIED {src_name} -> {dst_name}")
    return actions


# ============================
# PRD INDEX MANAGEMENT
# ============================

STATUS_RE = re.compile(r"^\s*(?:Status|PRD Status)\s*:\s*(.+?)\s*$", re.IGNORECASE | re.MULTILINE)


def infer_status(prd_md: str) -> str:
    m = STATUS_RE.search(prd_md or "")
    if not m:
        return "Draft"
    s = m.group(1).strip()
    return s if s else "Draft"


def ensure_prd_index_exists() -> None:
    if PRD_INDEX_PATH.exists() and PRD_INDEX_PATH.read_text(encoding="utf-8", errors="replace").strip():
        return
    header = "\n".join([
        "# PRD Index",
        "",
        "| PRD | Status | Calls | Last Generated (UTC) | Path |",
        "|---|---|---:|---|---|",
        "",
    ])
    write_text(PRD_INDEX_PATH, header)


def upsert_prd_index_row(prd_slug: str, status: str, calls_count: int, prd_dir: Path) -> None:
    ensure_prd_index_exists()
    md = read_text(PRD_INDEX_PATH)

    rows = md.splitlines()
    table_start = None
    for i, line in enumerate(rows):
        if line.strip().startswith("| PRD |"):
            table_start = i
            break
    if table_start is None:
        # recreate file if user changed it unexpectedly
        ensure_prd_index_exists()
        md = read_text(PRD_INDEX_PATH)
        rows = md.splitlines()
        for i, line in enumerate(rows):
            if line.strip().startswith("| PRD |"):
                table_start = i
                break
        if table_start is None:
            raise RuntimeError("PRD_INDEX.md table header not found and could not be created.")

    # Build new row
    last_gen = now_utc_date()
    rel = relpath_md(PRDS_ROOT, prd_dir)
    row = f"| {prd_slug} | {status} | {calls_count} | {last_gen} | [{rel}]({rel}) |"

    # Find existing row for slug
    slug_re = re.compile(rf"^\|\s*{re.escape(prd_slug)}\s*\|", re.IGNORECASE)
    replaced = False
    for i in range(table_start + 2, len(rows)):
        line = rows[i]
        if slug_re.match(line.strip()):
            rows[i] = row
            replaced = True
            break

    # Append at end of table if not found
    if not replaced:
        # Insert before trailing blank lines
        # Ensure there's at least one blank line after table.
        insert_at = len(rows)
        while insert_at > 0 and rows[insert_at - 1].strip() == "":
            insert_at -= 1
        rows.insert(insert_at, row)

    write_text(PRD_INDEX_PATH, "\n".join(rows))


# ============================
# GENERATION OUTPUTS
# ============================

def generate_research_summary_md(prd_dir: Path, call_folders: List[Path]) -> str:
    lines: List[str] = []
    lines.append("# Research Summary")
    lines.append("")
    lines.append("## Scope")
    lines.append(f"- Generated at (UTC): {now_utc_iso()}")
    lines.append(f"- Calls included: {len(call_folders)}")
    lines.append("")
    lines.append("## Included Calls")
    for cf in call_folders:
        rel = relpath_md(prd_dir, cf)
        lines.append(f"- [{cf.name}]({rel})")
    lines.append("")
    lines.append("## Call Summaries")
    for cf in call_folders:
        summ_path = cf / CALL_SUMMARY
        rel_call = relpath_md(prd_dir, cf)
        lines.append(f"### [{cf.name}]({rel_call})")
        if summ_path.exists():
            txt = read_text(summ_path).strip()
            # Keep it readable: extract only the "Key Problems" and "Desired Outcomes" sections if present
            key_blocks = []
            for section_name in ("Key Problems", "Desired Outcomes", "Recommended Follow-ups"):
                m = re.search(rf"^##\s*{re.escape(section_name)}\s*$([\s\S]*?)(?=^##\s|\Z)", txt, re.MULTILINE)
                if m:
                    block = m.group(0).strip()
                    key_blocks.append(block)
            if key_blocks:
                lines.append("\n\n".join(key_blocks))
            else:
                # fallback: first ~30 lines
                lines.append("\n".join(txt.splitlines()[:30]).strip())
        else:
            lines.append("_Missing 02_ai_summary.md_")
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def generate_key_items_md(prd_dir: Path, title: str, store: Dict[str, CanonicalItem]) -> str:
    lines: List[str] = []
    lines.append(f"# {title}")
    lines.append("")
    lines.append(f"- Generated at (UTC): {now_utc_iso()}")
    lines.append(f"- Canonical items: {len(store)}")
    lines.append("")
    items = sort_canonical(list(store.values()))
    for idx, it in enumerate(items, start=1):
        lines.append(f"## {idx:02d}. {it.title}")
        lines.append(f"- Frequency (calls): {len(it.occurrences)}")
        lines.append("- Evidence (examples):")
        examples = it.occurrences[:3]
        for o in examples:
            rel = relpath_md(prd_dir, o.call_folder)
            ts = o.timestamp or "unknown"
            quote = o.quote.strip() if o.quote else ""
            quote = quote if quote else "_No quote captured in this section._"
            lines.append(f"  - [{o.call_label}]({rel}) — {ts}")
            lines.append(f"    - Quote: {quote}")
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


# ============================
# CORE: GENERATE ONE PRD
# ============================

def generate_one_prd(prd_slug: str, templates_overwrite: bool = False) -> None:
    root = repo_root()
    prd_dir = root / PRDS_ROOT / prd_slug

    if not prd_dir.exists():
        raise SystemExit(f"ERROR: PRD folder does not exist: {prd_dir}\nCreate it and add 01_scope.md.")

    scope_path = prd_dir / SCOPE_FILE
    if not scope_path.exists():
        raise SystemExit(f"ERROR: Missing scope file: {scope_path}\nCreate 01_scope.md with a '## Calls' section.")

    # 1) Copy templates (saves time)
    actions = ensure_templates(prd_dir, overwrite=templates_overwrite)
    if actions:
        print("\n".join([f"[TEMPLATE] {a}" for a in actions]))

    # 2) Parse scope calls
    scope_md = read_text(scope_path)
    call_paths = parse_scope_calls(scope_md)
    if not call_paths:
        raise SystemExit("ERROR: No calls found under '## Calls' in 01_scope.md")

    # Resolve to absolute call folder paths (relative to repo root)
    call_folders: List[Path] = []
    for p in call_paths:
        cf = (root / p).resolve()
        if not cf.exists() or not cf.is_dir():
            raise SystemExit(f"ERROR: Call folder not found: {p} (resolved to {cf})")
        call_folders.append(cf)

    # 3) Deterministic aggregation
    jtbd_store: Dict[str, CanonicalItem] = {}
    ins_store: Dict[str, CanonicalItem] = {}

    for cf in call_folders:
        label = cf.name

        jtbd_path = cf / CALL_JTBD
        if jtbd_path.exists():
            for title, key, ts, q in extract_items(read_text(jtbd_path), "jtbd"):
                add_occurrence(jtbd_store, title, key, cf, label, ts, q)

        ins_path = cf / CALL_INSIGHTS
        if ins_path.exists():
            for title, key, ts, q in extract_items(read_text(ins_path), "ins"):
                add_occurrence(ins_store, title, key, cf, label, ts, q)

    # 4) Write outputs (generated)
    summary_out = prd_dir / "03_research_summary.md"
    jtbd_out = prd_dir / "04_key_jtbd.md"
    ins_out = prd_dir / "05_key_insights.md"

    write_text(summary_out, generate_research_summary_md(prd_dir, call_folders))
    write_text(jtbd_out, generate_key_items_md(prd_dir, "Key JTBD", jtbd_store))
    write_text(ins_out, generate_key_items_md(prd_dir, "Key Insights", ins_store))

    print(f"[WRITE] {relpath_md(root, summary_out)}")
    print(f"[WRITE] {relpath_md(root, jtbd_out)}")
    print(f"[WRITE] {relpath_md(root, ins_out)}")

    # 5) Update PRD index
    prd_md_path = prd_dir / "00_prd.md"
    status = "Draft"
    if prd_md_path.exists():
        status = infer_status(read_text(prd_md_path))
    upsert_prd_index_row(prd_slug, status, len(call_folders), prd_dir)

    print(f"[INDEX] Updated {relpath_md(root, root / PRD_INDEX_PATH)}")


# ============================
# DISCOVER PRDs (for --all)
# ============================

def discover_prd_slugs(root: Path) -> List[str]:
    prds_root = root / PRDS_ROOT
    if not prds_root.exists():
        return []
    slugs: List[str] = []
    for p in sorted(prds_root.iterdir()):
        if not p.is_dir():
            continue
        if p.name.startswith("_"):
            continue
        if (p / SCOPE_FILE).exists():
            slugs.append(p.name)
    return slugs


# ============================
# ENTRY POINT
# ============================

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Generate PRD scaffolding + deterministic research outputs from scoped call folders, and update PRD_INDEX.md."
    )
    parser.add_argument("--prd", type=str, default="", help="PRD slug under 03_prds/<prd-slug> to generate.")
    parser.add_argument("--all", action="store_true", help="Generate for all PRD folders in 03_prds/ that have 01_scope.md.")
    parser.add_argument("--overwrite-templates", action="store_true", help="Overwrite template-copied files if they already exist.")
    args = parser.parse_args()

    root = repo_root()

    prds_root = root / PRDS_ROOT
    if not prds_root.exists():
        raise SystemExit(f"ERROR: PRD root not found: {prds_root}")

    if not TEMPLATES_DIR.exists():
        raise SystemExit(f"ERROR: Templates folder not found: {root / TEMPLATES_DIR}")

    # Validate templates exist (at least the ones we copy)
    missing = [t for t in TEMPLATE_MAP.keys() if not (root / TEMPLATES_DIR / t).exists()]
    if missing:
        raise SystemExit(f"ERROR: Missing templates in {TEMPLATES_DIR}: {', '.join(missing)}")

    if args.all and args.prd:
        raise SystemExit("ERROR: Use either --prd <slug> OR --all, not both.")

    if args.all:
        slugs = discover_prd_slugs(root)
        if not slugs:
            print("No PRDs found with 01_scope.md under 03_prds/. Nothing to do.")
            return
        for slug in slugs:
            print("\n" + "=" * 80)
            print(f"PRD: {slug}")
            print("=" * 80)
            generate_one_prd(slug, templates_overwrite=args.overwrite_templates)
        print("\nDone.")
        return

    if not args.prd:
        raise SystemExit("ERROR: Missing --prd <prd-slug> (or use --all).")

    slug = safe_slug(args.prd)
    generate_one_prd(slug, templates_overwrite=args.overwrite_templates)
    print("\nDone.")


if __name__ == "__main__":
    main()
