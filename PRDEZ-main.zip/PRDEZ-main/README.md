# PRDEZ — Product Research & Discovery Engine (Local)

This repository is a **local, deterministic pipeline** for turning raw customer call transcripts into:
- Structured JTBD & insights
- Per-customer research records
- Cross-customer synthesis & trends
- Inputs for PRDs and roadmap decisions

The system is designed to be:
- **Repeatable** (same inputs → same outputs)
- **Auditable** (every insight links back to source calls)
- **Low-ceremony** (drop files → run one command)

---

## Mental Model

There are **three layers**:

### 1) Extraction (AI)
Azure OpenAI is used **only** to extract structured data from individual calls:
- JTBD
- Insights
- Evidence quotes
- Metadata (customer, call type)

This happens **per call**, never across calls.

### 2) Aggregation (Deterministic)
No AI.
Pure reduction:
- Calls → Customer rollups
- Customers → Cross-customer synthesis
- Frequency, recency, coverage, gaps

This ensures trust and reproducibility.

### 3) Usage
Humans (and later AI) consume:
- Customer folders
- Synthesis outputs
- PRDs

---

## Folder Structure (Key Paths)

```

01_library/
calls/
inbox/        # Drop raw .txt transcripts here
processed/    # Canonical call folders (do not edit manually)

customers/      # Auto-generated per-customer research <customer-id>/
CALLS.md
JTBD.md
INSIGHTS.md
CUSTOMER_OVERVIEW.md
_registry/
MISSING_CUSTOMER_METADATA.md

02_synthesis/     # Cross-customer trends
JTBD_CANONICAL.md
INSIGHTS_CANONICAL.md
THEMES.md
CONTRADICTIONS.md
EVIDENCE_GAPS.md

scripts/
run_pipeline.py # One command to rule them all

```

---

## End-to-End Workflow

### Optional: add your own context
- Fill in `USER_CONTEXT.md` (at repo root) with details like who the main user is, what product you work on, and any preferences or terminology.
- Lines starting with `#` are ignored, so you can keep the examples commented out or delete them entirely; the pipeline runs fine if the file is empty.

### 1) Add transcripts
- Save each call as a single `.txt` file.
- Drop the files into `01_library/calls/inbox/`.

### 2) Run the core pipeline
From repo root (requires Azure OpenAI environment variables; see `.env`):

```bash
python scripts/run_pipeline.py
````

What this does:
1. Ingests new transcripts (moves them into canonical call folders).
2. Analyzes any unprocessed calls with Azure OpenAI and writes structured outputs.
3. Refreshes per-customer JTBD and insights.
4. Rebuilds cross-customer synthesis files.

Common variants:
- Limit volume: `python scripts/run_pipeline.py --limit 10`
- Re-run analysis: `python scripts/run_pipeline.py --force`
- Target subset: `python scripts/run_pipeline.py --only bastion`
- Dry run: `python scripts/run_pipeline.py --dry-run`
- Skip steps: add `--skip-ingest`, `--skip-analyze`, `--skip-customers`, or `--skip-synthesis`

### 3) Scope a PRD
1. Create a folder under `03_prds/<prd-slug>/` (slug can be any lowercase kebab-case name).
2. Add a `01_scope.md` with a `## Calls` section listing call folders to include, e.g.:
   ```md
   ## Calls
   - 01_library/calls/processed/2024-10-12_acme-platform-upgrade
   - 01_library/calls/processed/2024-10-20_acme-renewal
   ```
3. Optional: add any background/context above or below the `## Calls` block.

### 4) Generate PRD research pack (deterministic)
This creates scoped research outputs and updates the PRD index:

```bash
python scripts/generate_prd.py --prd <prd-slug>
````

Outputs written to `03_prds/<prd-slug>/`:
- `03_research_summary.md` (call summaries + links)
- `04_key_jtbd.md` (canonical JTBD evidence)
- `05_key_insights.md` (canonical insights evidence)
- Templates copied from `_templates/` if missing (PRD, research guide, etc.)
- `PRD_INDEX.md` updated with call counts and status

### 5) Draft the PRD with Azure OpenAI
Requires Azure OpenAI environment variables (see `.env`).

```bash
python scripts/generate_prd_md.py --prd <prd-slug>
````

This fills `00_prd.md` using the PRD template plus the generated research files. Use `--force` to overwrite an existing PRD or `--all` to generate for every scoped PRD folder.

### 6) Optional: Generate hypotheses and user stories
Both commands use the already generated research pack and PRD.

```bash
python scripts/generate_prd_hypotheses.py --prd <prd-slug>
python scripts/generate_prd_user_stories.py --prd <prd-slug>
````

Outputs:
- `06_hypotheses.md` plus raw/run logs
- `07_user_stories.md` plus raw/run logs

---

## Common Flags

### Limit processing (useful for backfills)

```bash
python scripts/run_pipeline.py --limit 10
```

### Force re-analysis (ignores ANALYZED.flag)

```bash
python scripts/run_pipeline.py --force
```

### Target specific calls/customers

```bash
python scripts/run_pipeline.py --only bastion
```

### Dry run (no writes where supported)

```bash
python scripts/run_pipeline.py --dry-run
```

### Skip steps (advanced)

```bash
python scripts/run_pipeline.py --skip-ingest
python scripts/run_pipeline.py --skip-synthesis
```

---

## Reset Project to Clean Slate

To reset the project and remove all generated content (useful for sharing a clean repository):

```bash
python scripts/reset_project.py
```

This will:
- Delete all files in `01_library/calls/inbox/`
- Delete all processed call folders (preserves `_call_template/` if it exists)
- Delete all customer directories (including `_registry/`)
- Delete synthesis content files (preserves `README.md`)
- Delete all PRD folders (preserves `_templates/`)
- Reset `PRD_INDEX.md` to header-only template

**Preserved:**
- All scripts in `scripts/`
- Templates in `03_prds/_templates/`
- Call template in `01_library/calls/_call_template/` (if exists)
- Documentation files (`README.md`, `USER_CONTEXT.md`, etc.)

**Safety features:**
- Preview changes: `python scripts/reset_project.py --dry-run`
- Skip confirmation: `python scripts/reset_project.py --force`
- Verbose output: `python scripts/reset_project.py --verbose`

---

## How "Processed" State Works



* **Truth**: `ANALYZED.flag` file inside a call folder
* **Visual**: folder name ends with `✅`

The emoji is purely visual.
The flag is what the system actually trusts.

Do **not** delete `ANALYZED.flag` unless you want the call reprocessed.

---

## Metadata Rules (Important)

Each call folder contains:

```
00_metadata.md
```

Key fields:

```md
- Customer: WestCord Hotels
- Customer ID: westcord
- Call type: discovery
```

Rules:

* `Customer ID` is the canonical key (slug, lowercase)
* AI will attempt to fill metadata if missing
* If metadata is unclear, it is marked as `UNKNOWN`

All unresolved cases are listed here:

```
01_library/customers/_registry/MISSING_CUSTOMER_METADATA.md
```

Fixing this file dramatically improves synthesis quality.

---

## When Things Look “Empty”

If synthesis files are empty, it means **upstream layers are empty**, not that the pipeline failed.

Check in this order:

1. `03_ai_jtbd.md` / `04_ai_insights.md` inside a call folder
2. `01_library/customers/<customer>/JTBD.md`
3. `02_synthesis/INSIGHTS_CANONICAL.md`

The pipeline never invents data.

---

## Design Constraints (By Intent)

* ❌ No AI at aggregation/synthesis layers

* ❌ No hidden state

* ❌ No silent inference

* ✅ Everything traceable to calls

* ✅ Deterministic outputs

* ✅ Safe to rerun repeatedly

---

## Environment Requirements

* Python 3.9+
* `openai` SDK installed
* `.env` populated with Azure OpenAI values:

```bash
AZURE_OPENAI_RESPONSES_URL=https://mews-bi-agent-experiment-sandbox.cognitiveservices.azure.com/openai/responses?api-version=2025-04-01-preview
AZURE_OPENAI_ENDPOINT=https://mews-bi-agent-experiment-sandbox.cognitiveservices.azure.com/
AZURE_OPENAI_API_VERSION=2025-04-01-preview
AZURE_OPENAI_DEPLOYMENT=gpt-5.1-call-analyzer
AZURE_OPENAI_API_KEY=your_key_here
```

---

## Next Extensions (Optional)

* PRD auto-generation from synthesis
* “Legacy cleanup” mode for old bullet-only calls
* AI-assisted hypothesis generation (read-only)

---

## Philosophy

> AI is a microscope, not a brain.
> Aggregation is math, not opinion.
> Every insight must earn its way upstream.

---

**If in doubt:**
Drop files → run `run_pipeline.py` → read the outputs.
