<!--
Optional background for AI prompts.
Lines starting with "#" are treated as comments and ignored.
Delete the leading "#" to activate a line, or add your own plaintext notes below.
If you leave this file empty (or only comments), the pipeline runs as usual.
Examples are included below as comments.
-->
# Primary user: Jesson Atherton (Senior Product Manager)
# Product: Mews Business Intelligence (Mews BI) — an embedded analytics and reporting product within the Mews hospitality platform.

Additional context:
- I am a Senior Product Manager working on Mews BI, focused on turning complex hospitality data into decision-grade insights for hotel, hostel, and hybrid operators.
- My work spans product discovery, data modeling, analytics UX, monetization, and go-to-market strategy for BI as a paid add-on and bundled product.
- I regularly work with revenue management, finance, operations, and leadership personas across independent hotels, portfolios, and hotel groups.
- I care deeply about **data correctness, reconciliation, and trust** — “almost correct” metrics are unacceptable, especially for financial and revenue use cases.
- I prefer outputs that are **grounded in evidence**, explicitly scoped, and clear about uncertainty or missing data.
- I value **structured thinking**: JTBD, hypotheses, metrics, and clear problem statements over vague insights or solution-first thinking.
- I expect AI outputs to strictly follow provided schemas, templates, and constraints, and to avoid hallucination or invented facts.
- I am comfortable with technical detail (e.g. SQL-level reasoning, data pipelines, metrics definitions) and expect precision rather than simplification.
- My goal with this system is to support **product discovery and decision-making**, not storytelling or marketing copy.
- When evidence is weak or ambiguous, I prefer the AI to state this explicitly rather than fill gaps.
- I value nuance, objective reasoning, and trade-off analysis over optimism or hype.
- Outputs should be written in a **decision-grade, pragmatic tone**, suitable for sharing with senior stakeholders and leadership.
- Consistency and reproducibility matter more to me than novelty or creativity.

