# Synthesis

- `JTBD_CANONICAL.md` — ranked cross-customer JTBD
- `INSIGHTS_CANONICAL.md` — ranked cross-customer insights
- `THEMES.md` — heuristic theme buckets
- `CONTRADICTIONS.md` — heuristic keyword tensions
- `EVIDENCE_GAPS.md` — recurring items with weak captured quotes

Tip: re-run after updating customer metadata and regenerating customer rollups.
