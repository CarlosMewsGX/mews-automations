# Research Summary — <PRD Title>

## Calls Included
> List the canonical calls (folders) and why they were included.

- Call: <link or path> — Why included:
- Call: <link or path> — Why included:

## Executive Summary (max 10 bullets)
- 
- 
- 

## Key Insights (evidence-based)
### INS-001: <Insight statement>
- Evidence:
  - Call:
  - Timestamp:
  - Quote:
- Interpretation:
- Implications for PRD:

### INS-002: <Insight statement>
- Evidence:
- Interpretation:
- Implications for PRD:

## JTBD Relevant to This PRD
### JTBD-001: <Job title>
- Who:
- When:
- Desired outcome:
- Evidence:
- Notes:

## Themes & Patterns
- Theme 1:
- Theme 2:

## Contradictions / Mixed Evidence
- Contradiction:
  - Evidence for A:
  - Evidence for B:
  - What we need to learn next:

## Evidence Gaps
- Gap 1:
- Gap 2:

## Recommendations
- Build / test:
- Defer / discard:
- Next research steps:
