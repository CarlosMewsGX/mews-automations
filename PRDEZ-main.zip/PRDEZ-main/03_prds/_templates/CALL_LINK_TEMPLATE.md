# Link: <Call name>

Canonical call folder:
- `../../../../01_library/calls/processed/<folder>/`

Why included:
- 

Key files:
- `00_metadata.md`
- `02_ai_summary.md`
- `04_ai_insights.md`
- `05_evidence_clips.md`
