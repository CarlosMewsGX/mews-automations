# Research Guide — <PRD Title>

## Objective
What decision(s) this research should inform:
- Decision 1:
- Decision 2:

## Research Questions
> Keep this tight. These are the questions you want the calls to answer.

1.
2.
3.
4.
5.

## Target Participants
- Customer segment(s):
- Personas / departments:
- Must-have characteristics:
- Nice-to-have characteristics:

## Call Types Included
- Discovery:
- Validation:
- Usability / concept test:
- Support / escalation (if relevant):

## Discussion Guide
### 1) Context & workflow (5–10 mins)
- “Walk me through how you do X today.”
- “What tools/reports do you use?”
- “What is the trigger that makes you do this?”

### 2) Pain & impact (10–15 mins)
- “What goes wrong most often?”
- “How do you notice it’s wrong?”
- “What is the cost (time, money, trust, missed decisions)?”

### 3) Definitions & trust (10–15 mins)
- “How do you define <metric>?”
- “What report is the source of truth?”
- “What needs to reconcile for you to trust it?”

### 4) Current workarounds (5–10 mins)
- “What do you do instead?”
- “Who is involved?”
- “What is manual vs automated?”

### 5) Success & acceptance (5–10 mins)
- “What would ‘great’ look like?”
- “What would make you adopt this immediately?”
- “What would block adoption?”

## Artifacts to Collect
- Screenshots of reports
- Example exports (Excel/CSV)
- Definitions docs / SOPs
- Sample data (if possible)

## Output Format
This research should produce:
- Key insights (with evidence)
- JTBD relevant to this PRD
- Risks / contradictions / evidence gaps
- User stories + acceptance criteria candidates
