# PRD: <Title>

## Summary
<5–8 sentences. Decision-grade. No quotes. Link to research pack below.>

## Problem Statement
- Who is experiencing the problem:
- What they are trying to do:
- Why they fail today (root cause, not symptoms):
- Why now:

## Goals
- G1:
- G2:
- G3:

## Non-Goals
- NG1:
- NG2:

## Users & Use Cases
### Primary personas
- Persona 1:
- Persona 2:

### Top use cases
1.
2.
3.

## Scope
### In scope
- S1:
- S2:

### Out of scope
- O1:
- O2:

## Solution Outline
> High-level approach. Details can live in design/tech docs.

- UX / workflow:
- Data model / definitions:
- Permissions / governance:
- Export / interoperability:

## Requirements
### Functional requirements
- FR1:
- FR2:

### Non-functional requirements
- NFR1: Performance
- NFR2: Accuracy / reconciliation expectations
- NFR3: Auditability / explainability
- NFR4: Internationalisation (currency, timezone, locale)

## Success Metrics
- Adoption:
- Engagement:
- Trust / reconciliation:
- Time saved / workflow reduction:
- Revenue / retention (if applicable):

## Risks & Assumptions
### Assumptions
- A1:
- A2:

### Risks
- R1:
- R2:

## Open Questions
- Q1:
- Q2:

## Dependencies
- Team / system dependency:
- Data dependency:
- Legal / consent dependency (if relevant):

## Rollout Plan
- Beta / pilot:
- GA criteria:
- Backwards compatibility / migration:

## Evidence & Research
- Research pack: `./research/02_research_summary.md`
- Calls included: `./research/01_calls_included.md`

## Appendix
- Links to designs:
- Links to tickets:
- Links to dashboards / metrics:
