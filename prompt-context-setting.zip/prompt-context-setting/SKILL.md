---
name: Prompt Context Setting
description: Apply the context setting element when constructing a prompt: role or persona, key task, goal, audience, channel, participants, and scenario. Use when starting any new prompt.
---

# SKILL: Prompt Context Setting

## Purpose
Before writing detailed instructions, set the stage so the model can step into the situation effectively. Context provides background about the task, its high-level output, the underlying goal, the participants involved, the communication channel, and the scenario. Without context, the model makes assumptions — and those assumptions tend to be wrong.

---

## Core Formula

Use this formula to frame any prompt:

```
Role or Persona + Situation + Key Task + End Goal

As a [role], when I'm [situation], I want to [key task] so I can [goal].
```

**Example:**
> As a Sales Development Representative, when I'm reaching out to a new prospect, I want to create a personalised introduction email so I can get a response and initiate a conversation.

---

## Elements of Context Setting

### 1. Role or Persona

Define who the model is acting as. This governs tone, style, expertise, and decision-making approach.

**Patterns:**
- `You are a [role].`
- `Your role is [role].`
- `You are a [adjective] [role] with expertise in [scope of knowledge].`
- `You are a [role] who assists a [human role or title].`

**Sub-elements to include for complex roles:**

| Sub-element | Purpose | Pattern Examples |
|---|---|---|
| **Scope** | Narrow the area of expertise | `You have expertise in [scope]` / `...responsible for [area]` |
| **Job** | Describe key responsibilities | `...and your job is to [description]` / `...focused on [responsibilities]` |
| **Details** | Ground in specifics (name, company, industry) | `...at a company called [name]` / `...and your name is [name]` |
| **Relational Stance** | Define relationship to a human actor | `...who assists a [human role]` / `...assisting a [title]` |
| **Tone** | Establish behavioural cues | `...and communicates in a [style] manner` / `You prioritize [style] communication` |

**Important rules:**
- Use `You are a...` or `Your role is...` — **never** `Imagine you are...` or `Act as...` (invites hallucination)
- Contractions (`you're`, `your`) produce more casual, conversational responses
- Skip role definition for straightforward tasks like verbatim text extraction
- Match role detail to task complexity: simple tasks need a title; complex tasks benefit from full persona
- Stay consistent — use the same participant names and terms throughout the prompt

---

### 2. Key Task

State ONE clear main task at the start of the prompt. This acts as a filter for everything that follows.

**Patterns:**

| Pattern | Examples |
|---|---|
| `Your task is to [action verb]...` | `Your task is to summarise the overall impressions mentioned in a presentation.` |
| `Your objective is to [action verb]...` | `Your objective is to extract contact details from the input.` |
| `[Imperative action verb]...` | `Generate a bulleted list of...` |
| `You're tasked with [action verb]...` | `You're tasked with drafting a follow-up email after [preceding event].` |

**High-Level Output Description patterns:**

| Pattern | Examples |
|---|---|
| `[article] + [adjective] + [noun]` | `a concise summary`, `a detailed analysis`, `a bulleted list` |
| `a draft of [noun phrase]` | `a draft of a sales proposal`, `a draft of a warm introduction email` |
| `[noun phrase] of [content or topic]` | `a numbered list of the top 3 opportunities`, `a concise summary of next steps` |
| `[noun phrase] of [data description]` | `a summary of a call transcript`, `a detailed analysis of the case below` |
| `[noun phrase] in [format]` | `a summary in Markdown`, `a list of action items formatted in HTML` |

**For unstructured input** (e.g. transcripts), name the specific topics to focus on upfront:
- `Your task is to summarise [A], [B], and [C] in [Data].`
- `Your task is to extract information about [A], [B], and [C] from [Data].`

**Best practices:**
- Start with one clear main task — add detail in the Instructions section
- Use strong action verbs: generate, extract, summarise, classify, draft, identify, analyse
- Briefly note the output format upfront: `Generate a bulleted list of...`
- Avoid combining multiple tasks — keep this step simple

---

### 3. Goal or Outcome

Explain *why* the task matters or how the output will be used. This helps the model make better choices and go beyond simply following instructions.

**Use the Five Whys technique** to find the real underlying goal — not just the surface task. Start with the key task and ask "why?" up to five times.

**Example:**
> Task: Summarise a client's account for a meeting
> 1. Why? → To quickly review their financial status
> 2. Why? → To identify trends or issues for discussion
> 3. Why? → To tailor recommendations to their situation
> 4. Why? → To show you understand their business
> 5. Why? → To build a stronger relationship with them
>
> **Real goal:** Deepen the client relationship — not just produce a summary.

**Goal Description Patterns:**

| Pattern | Examples |
|---|---|
| `so that [audience] can [goal]` | `...so that the support agent can quickly understand the issue` |
| `so [audience] can [goal]` | `...so the manager has a comprehensive overview before the meeting` |
| `to [infinitive verb phrase]` | `...to identify key customer pain points` / `...to generate a follow-up plan` |
| `in order to [goal or outcome]` | `...in order to prepare for the client meeting` |
| `for a [goal or outcome]` | `...for a new marketing campaign` |
| `for the purpose of [goal or outcome]` | `...for the purpose of escalating the case appropriately` |
| `The output will be used to [goal or outcome]` | `The output will be used to determine the next stage.` |

**Best practices:**
- Keep goal statements concise — focus on impact, not process
- Consider: what business problem does this solve? What is the desired impact (efficiency, engagement, accuracy)?
- Use the goal to align the model's choices with broader objectives

---

### 4. Participants and Relationships

Define who is involved and how participants relate to each other. This enables role-based behaviour, improves relevance, and provides a foundation for complex interactions.

**Participants include:**
- The AI model itself (acting as agent or assistant)
- Human actors (sender, recipient, user)
- Systems (APIs, platforms, downstream consumers)

**Distinguish between:**
- LLM as **sender**: introduces itself as the agent (`I'm [AI Name], an automated AI from [Company].`)
- LLM as **assistant to sender**: introduces itself as assistant (`I'm a virtual assistant for [Sender Name].`)

**Human actor information to include:**
- Name, role, title
- Job description or responsibilities
- Company or organisation
- Relationship context (e.g. new lead, long-term partner, recently onboarded customer)

**Relationship patterns:**
- `You are [role] assisting a [human role] in reaching out to potential customers.`
- `You are an assistant to a [human role or title].`
- `The [recipient] has previously connected with your team through [source].`

**Best practices:**
- Skip participant definition for tasks that don't involve interpersonal dynamics
- Scale detail to complexity: a title suffices for simple tasks; multi-party interactions need full definitions
- Stay consistent — use the same names and terms throughout the prompt

---

### 5. Audience

Specify characteristics of the person or group who reads and uses the output. Designating a system as the audience shifts focus from human readability to machine-parsability.

**Audience types to consider:**

| Type | Examples |
|---|---|
| Role | Sales Manager, Account Executive |
| Expertise | Non-technical user, subject-matter expert |
| Relationship | Prospective client, long-term strategic partner |
| Seniority | C-level executive, individual contributor |
| Context familiarity | Someone unfamiliar with Project X, new to the company |
| Departmental/team | Customer Service team, regional sales managers |
| Systems | External API, nightly data pipeline, REST endpoint |

**Audience Patterns:**

| Pattern | Examples |
|---|---|
| `...to [actor]` | `...to new customers` / `...to the sales team` |
| `...shared with [actor]` | `...shared with a sales manager` |
| `...for [actor]` | `...for a technical manager` / `...for internal review` |
| `...to be [past participle] by [actor]` | `...to be consumed by our analytics dashboard` |
| `...for [system] expecting [format]` | `...for a flow expecting JSON input` |

---

### 6. Scenario and Setting

Provide context about the environment, circumstances, and output channel. This influences style, tone, and format.

**Key considerations:**
- **Interaction type**: chat-based, voice, SMS, face-to-face
- **Physical channel**: phone, email, web chat, video call
- **Situation or history**: the circumstances that led to this task
- **Entry point**: autonomous trigger, user action, button click
- **Time constraints**: urgency, deadlines, relevant timeframe

**Output Channel Patterns:**

| Type | Pattern Examples |
|---|---|
| Channel | `[output] will be used in [channel]` / `[output] in [channel]` |
| Device Type | `[output] is intended for display on [device]` |
| System | `The [output] will populate the [field name] field in a [object] record` |

**Triggering Event Patterns:**

| Type | Pattern Examples |
|---|---|
| Condition or Context | `This task is needed because [condition]` / `Current business context:` |
| Preceding Event | `Triggering event: [preceding event]` / `[preceding event], so you need to [action]` / `You're tasked with [action] after [preceding event]` |

**Time Context Patterns:**

| Type | Pattern Examples |
|---|---|
| Time Frame | `...for [time frame]` |
| Real-Time | `This is a real-time response to a user query.` |
| Date-Bound | `...which must be no later than [date]` / `...which can be earlier than [date]` |

**Best practices:**
- Define the output channel explicitly — it governs length, format, and tone conventions
- Without a scenario, the model fills in gaps with assumptions that tend to be wrong
- Specifying channel reduces token usage — the model infers style conventions from channel context

---

## Context Setting Checklist

Before moving to Instructions, verify:

- [ ] Role defined using `You are a...` or `Your role is...` (not `imagine` or `act as`)
- [ ] One clear key task stated with a strong action verb
- [ ] Output format briefly noted in the key task
- [ ] Underlying goal stated (not just the surface task)
- [ ] Audience identified
- [ ] Output channel specified
- [ ] Any triggering event or time context noted
- [ ] Participant relationships defined if relevant
- [ ] Consistent naming and terminology established
