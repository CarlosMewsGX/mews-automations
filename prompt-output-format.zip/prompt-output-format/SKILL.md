---
name: Prompt Output Format
description: Apply output format guidance when constructing a prompt: structure types, Markdown, HTML, JSON, links, length constraints, and number formatting.
---

# SKILL: Prompt Output Format

## Purpose
Output format is the blueprint for the structure and presentation of model output. These instructions guide the model on how to structure and present content so the audience easily understands it. Thoughtful formatting is not about aesthetics — it is about ensuring the output is usable and achieves its intended goal.

**Why format matters:**
- **Clarity** — clear formatting makes complex information digestible
- **Readability** — consistent use of headings, bullet points, and spacing guides the reader's eye
- **Professionalism** — well-formatted output signals attention to detail
- **Usability** — predictable structure helps users locate what they need quickly
- **System integration** — specifying formats like JSON or CSV enables seamless downstream use
- **Efficiency** — well-formatted output reduces token use and avoids unnecessary follow-up prompting

---

## Guiding Questions

Before specifying output format, ask:

- Who is the audience and how do they use this information? On a screen, in print, or in another system?
- What is the primary goal of the output — to inform, instruct, summarise, or drive action?
- What type of information is being presented — text, numerical data, code, or a combination?
- Where is this output displayed or used? Are there platform-specific constraints?
- Does the output need to be parsed by other systems? If so, consider structured formats like JSON or CSV.
- What are the relevant length restrictions for the target system or user preferences?
- Is consistency important across different outputs in this application or system?

---

## Structure and Organisation

### Paragraphs
Best for narrative explanations, detailed descriptions, and flowing text.

### Bullet Points
Ideal for listing key features, benefits, action items, or concise pieces of information where order doesn't strictly matter.

### Numbered Lists
Use when the order of items is important, such as steps in a process or ranked lists.

### Tables
Perfect for presenting structured data with rows and columns, allowing for easy comparison and analysis.

### Headings and Subheadings
Use to create a clear hierarchy and break down large amounts of information into logical sections, making content easy to scan.

### Structured Formats (JSON, XML, CSV)
Specify these when the output needs to be parsed and used by other applications or systems.

---

## Visual Formatting

| Element | Use |
|---|---|
| **Bold** | Emphasis on key terms, labels, or important values |
| *Italics* | Citations, foreign language terms, or subtle emphasis |
| Underline / strikethrough | Use sparingly — e.g. marking outdated information |
| Visual separators | Horizontal rules or whitespace to divide sections |

---

## Length Considerations

- **Overall length**: specify maximum word counts, character limits, or line counts for the entire response
- **Section-specific**: define length constraints for individual parts, e.g. `keep subject lines within 60 characters to avoid truncation`

### Character Limit Patterns

| Pattern | Examples |
|---|---|
| `...within [number] words` | `Generate an email within 100 words.` |
| `...under [number] characters` | `Keep responses brief (under 150 characters when answering questions)` |
| `...must not exceed [number] words` | `Your feedback must not exceed 300 words.` |

---

## Markdown

A lightweight, versatile syntax for structuring text for readability and web presentation.

**Important:** Do not assume the model will default to Markdown — explicitly state the requirement.

**Rules:**
- For common elements (headings, lists, emphasis), direct commands usually suffice
- For complex structures (tables, nested elements), provide detailed guidance or examples
- Avoid vague commands: `Make it look nice` is far less effective than `Use H2 headings for sections and bold for key terms`

### Patterns

| Pattern | Examples |
|---|---|
| `Use Markdown syntax [format]` | `Use markdown format to mark title, section names with heading tag, bold labels and bullets.` |
| `Use Markdown syntax [format] in the output` | `Use markdown syntax in output for title, header, and labels.` |
| `Format your output in Markdown` | `Format your output in Markdown. The main title should be a H1 heading, and key sections should be H2 headings.` |

---

## HTML

Use when output needs to be rendered in a UI. Include explicit instructions about which tags to use and exclude. A show-and-tell approach helps significantly.

### Examples

```
You must generate the output in HTML structure with the following tags:
<h1></h1>, <p></p>, <ul></ul>, and <li></li>.

The <h1></h1> tag is for the titles Overall Impression, Key Strengths, Growth Opportunities only.
The <p></p> tag is for paragraphs only.
The <ul></ul> and <li></li> tags are for bullet points only.
```

```
Formatting & Structure Guidelines:
Use <p> with <b> for section titles. Do not use heading tags (<h1>, <h2>).
Use <ul> and <li> for lists.
No CSS, no code block formatting.
```

```
If no data is available, return:
<p>We couldn't find any data to generate the summary.</p>
```

**Common HTML guardrails to include:**
- `Do not generate any styles or CSS.`
- `Do not generate code block formatting.`
- `Titles should be bold, wrapped in <b>.`
- `Do not include any line breaks or <br> tags.`
- `Wrap the entire output inside <section></section>.`

---

## Links and URLs

When you want the model to provide clickable URLs in its output, specify the exact format and location.

| Pattern | Examples |
|---|---|
| `...include a clickable URL. The link text should be [link text] and the URL is [URL].` | `When mentioning how users can sign up, include a clickable URL. The link text should be "Enrol Now" and the URL is https://example.com/enrol.` |
| `The [link text] must link to the [item] URL.` | `The Record Name in the Summary title must link to the Record URL.` |
| `Include a button which links to [URL].` | |
| `...link [item] to its [type] URL by creating a link to the [URL] field.` | |

---

## JSON

Use when your engineering team needs to read the output to populate UI fields or pass data to another system. A show-and-tell approach helps.

### Patterns

| Pattern | Examples |
|---|---|
| `Generate a JSON object with the keys [list keys].` | `Generate a JSON array where each item is an object with the keys "title", "date", and "details".` |
| `...generate [item] in JSON structure with the following keys: [key1] and [key2]` | `You must generate the email in JSON structure with the following keys: subject and body.` |
| `Your output must contain each of these items in JSON format: [list]` | List each field on a new line. |

### Example JSON structure instruction

```
You must generate the email in JSON structure with the following keys: subject and body.
{"subject": value,
 "body": value}
```

**Common JSON guardrails:**
- `If any individual key does not have a value, do not return a key for it.`
- `If all requested fields are empty or blank, return a {} as an empty JSON response.`

---

## Monetary Values and Numbers

### Currency
```
For monetary values, convert the currency code to its corresponding currency symbol.
Do not include the currency code.
```
Example: `100USD` → `$100`

### Numbers
```
You must spell out numbers that refer to the amount of objects, if the number is lower than 10.
```
Example: `three contacts, four accounts, 12 meetings`

---

## Output Format Checklist

- [ ] Structure type specified (paragraphs, bullets, numbered, table, etc.)
- [ ] Heading hierarchy defined if using headings
- [ ] Markdown explicitly requested if needed — never assumed
- [ ] HTML tag set specified if rendering in a UI, with CSS and code block generation prohibited
- [ ] JSON key names defined and example structure provided if needed
- [ ] URL/link format specified if clickable links are required
- [ ] Character or word limits set for the full response and for individual sections
- [ ] Currency symbols and number spelling conventions specified if relevant
- [ ] Fallback output defined for when no data is available
